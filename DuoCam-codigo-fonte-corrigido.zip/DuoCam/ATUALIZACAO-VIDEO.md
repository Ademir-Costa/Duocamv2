# DuoCam — correção do indicador de reprodução

Atualização de 4 de novembro de 2026. O usuário informou que o aplicativo instalado mostrava conectado/ao vivo sem imagem ao usar a URL candidata `rtsp://192.168.169.1:5000`.

## Correção realizada no código

A versão anterior ligava o indicador AO VIVO e cancelava o prazo de conexão quando recebia onPlaying ou qualquer onProgress do VLC. Isso não verificava a existência de uma faixa de vídeo. A versão corrigida exige dimensões válidas da faixa e avanço do tempo do player, passa a mostrar REPRODUZINDO e não interpreta esses eventos como prova de quadros visíveis no Android.

Sem essa evidência em 25 segundos, o aplicativo informa que não confirmou reprodução de vídeo. Após evidência inicial, 15 segundos sem novo progresso válido resultam em aviso de interrupção. Erro, parada ou timeout são terminais para aquela tentativa; eventos tardios não a restauram. Para tentar novamente, use Conectar, criando uma nova sessão. A área nativa do player também recebeu tamanho explícito para ocupar o visor.

Foram corrigidos o modelo informado no cadastro/ajuda para V100 e o texto literal de quebra de linha nos títulos. Dados de nome, rede e URL salvos não foram alterados.

## Limites que permanecem

Esta atualização é de código-fonte, não um APK novo. Ela não modifica o aplicativo já instalado no telefone. É necessário compilar e instalar a versão corrigida, preservando o identificador Android e a chave de assinatura para atualizar a instalação existente.

O erro do indicador e o problema de comunicação são assuntos diferentes. Não foram confirmados o serviço na porta 5000, a URL real de vídeo da V100 nem uma eventual autenticação específica do fabricante. A senha Wi-Fi continua sendo informada nos ajustes Android nesta versão. Não foi implementada descoberta automática nem negociação proprietária de sessão.

Nas capturas fornecidas, a conexão detalhada do Viidure para 192.168.1.1:3333 tinha zero bytes recebidos e nenhum payload de aplicação. O rótulo Ativo do capturador, sozinho, não comprova conexão estabelecida. Outras portas na lista podem ser tentativas de descoberta; não devem ser convertidas em URLs RTSP por suposição. A informação útil será a conexão que recebe dados enquanto o Viidure realmente exibe imagem dessa mesma câmera.

## Preparar uma nova instalação

Use o código salvo deste projeto no fluxo de compilação Android do painel. O APK precisa conter o módulo VLC; Expo Go não inclui esse módulo. Não publique uma versão como compatível com V100 antes de reproduzir vídeo real no aparelho. Se o build foi feito fora do painel, compile o código atualizado no mesmo ambiente e use a mesma assinatura da instalação anterior.

As verificações de TypeScript, testes de regras de reprodução e exportação JavaScript são distintas da compilação e do teste Android físico. Consulte TODO.md e ENTREGA.md para o estado dessas verificações. O telefone e as câmeras do usuário não estão acessíveis pela rede do Sandbox.
