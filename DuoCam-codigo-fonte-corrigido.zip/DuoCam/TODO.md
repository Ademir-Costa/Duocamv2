# DuoCam — versão aprovada

- [x] **Duas câmeras salvas e visualização sequencial.** Dois painéis Câmera 1/Câmera 2, cadastro editável de nome, rede e URL, persistência local; somente um player ativo nas redes independentes. Selecionar outra câmera encerra a anterior. Abrir ajustes Wi-Fi do Android, retornar e iniciar conexão explicitamente; não prometer troca silenciosa nem simultaneidade. Evidência: provider/validação, tela principal, formulário pós-hidratação e testes de sessão.
- [x] **Player e estados reais — integração em código.** Fronteira nativa RTSP/HTTP com biblioteca aberta; estados aguardando, conectando, reproduzindo, erro; parar/reconectar, áudio, ampliação. Nenhuma imagem ou métrica simulada apresentada como real. URL validada sem assumir endpoint da VT-100. Evidência: player Web/nativo, callbacks e exportação JS Web/Android. O funcionamento no equipamento permanece pendente abaixo.
- [x] **Fotos e gravação local — integração em código.** Expor captura de quadro e gravação local do stream nos players nativos compatíveis; salvar só após resposta de sucesso; tratar erros. Diferenciar gravação local de comandos no cartão da câmera. Evidência: callbacks com normalização file URI, adaptação de falhas de snapshot, geração de gravação e invalidação no timeout; testes de caminho. Captura real ainda exige APK/dispositivo.
- [x] **Biblioteca e downloads — implementação local.** Índice persistente das fotos/gravações reais, reprodução e compartilhamento; download por URL direta informada sem simular listagem remota do cartão. Não enviar mídia para cloud. Evidência: serviços expo-file-system/AsyncStorage, tela Arquivos/detalhe, validação e testes de mídia. Operações nativas não foram executadas em câmera física.
- [x] **Interface Android original.** Português brasileiro, estilo instrumental grafite/âmbar, controles amplos, ícone original e áreas seguras. Navegação entre câmeras, arquivos e ajustes/ajuda; sem reutilização de recursos do Viidure. Evidência: telas/componentes, seis arquivos de ícone originais e configuração de marca.
- [x] **Limites e preparação de entrega.** Informar que Web/Expo Go não validam RTSP/VT-100 e que módulo nativo precisa build. Preparar configuração e versão para gerar APK no painel; verificar TypeScript, testes de sessão única e revisão read-only das integrações. Não declarar APK entregue sem resultado real. Evidência: help/ENTREGA.md, plugins Expo/Gradle, introspecção Expo sem erro, TypeScript aprovado, 46 testes gerais aprovados e 21 testes afetados aprovados após os ajustes da revisão. Prévia HTTP 200 e ambos listeners ativos.

## Dependências de equipamento, não entregues nesta versão

- [ ] Confirmar protocolo/URL e testar VT-100 em dispositivo real.
- [ ] Gerar e validar APK Android e integração VLC na versão atual do React Native.

A exportação JavaScript Android passou com `--no-bytecode` exclusivamente para contornar o Hermes x86-64 instalado no Sandbox ARM64. Isso não é um build APK nem uma validação de hardware, e não mudou o motor do aplicativo.

Não fazem parte da versão aprovada: vídeo simultâneo nas duas redes próprias, comandos OEM/SD, listagem remota, editor avançado, AR/IA, GPS e serviços pagos do Viidure.

## Correção de indicação de vídeo — 4 de novembro de 2026

- [x] **Não declarar vídeo ativo só por eventos de conexão ou progresso.** Exigir dimensões válidas da faixa de vídeo e avanço do tempo do player; usar o rótulo REPRODUZINDO, sem afirmar verificação de quadros visíveis. Sem essa evidência em 25 segundos, informar ausência de confirmação de vídeo. Se o tempo parar de avançar durante 15 segundos, sinalizar interrupção. Falha, encerramento ou tempo esgotado não podem ser revertidos por callbacks tardios da mesma tentativa; reconexão exige uma nova geração. Nenhuma dessas correções confirma a porta 5000 ou a compatibilidade da V100.
- [x] **Corrigir identificação no cadastro.** Mostrar V100, modelo corrigido pelo usuário, e uma quebra de linha real no título, não o texto literal \\n. Preservar nomes de rede e URLs já salvos.

Evidência desta atualização: TypeScript aprovado, 32 testes novos do monitor de reprodução aprovados, total de 78 testes aprovados e 1 teste do starter ignorado; exportação JavaScript Web e Android aprovada sem bytecode. O código novo não foi compilado em APK nem executado na V100. A instalação anterior mostrada pelo usuário não valida a correção atual nem a reprodução física.

## Descoberta de vídeo baseada no Veecar — 5 de novembro de 2026

- [x] **Consultar mídia antes de reproduzir.** No modo Descobrir V100, executar no aparelho apenas GET /app/getdeviceattr e /app/getmediainfo no gateway privado configurado. Validar HTTP, JSON, result/info, identificação e URL; usar rtsp/rtsps informado, nunca converter a porta de mensagens em URL nem inventar fallback. Informar falhas sem credenciais, dados brutos ou falsa confirmação de vídeo.
- [x] **Cadastro e transporte compatíveis com dados existentes.** Manter os dois cadastros e a sessão única; preservar nomes/SSID/URLs legados no modo manual, oferecer descoberta experimental por gateway padrão 192.168.169.1 editável e transporte Automático/TCP/UDP. Modo automático segue transporte reconhecido ou negociação VLC, sem impor TCP. Não alterar senha ou parâmetros da câmera.
- [x] **Cancelar descoberta ao sair ou trocar.** Montar player só depois de obter URL válida; abortar consultas ao parar/trocar/sair e ignorar respostas tardias. Web/Expo Go não tentam acessar a câmera. Indicar endereço descoberto sem query/credenciais e separar descoberta HTTP de evidência de reprodução.
- [x] **Preparar entrega atualizada.** Verificar TypeScript, fixtures de descoberta, cancelamento, preservação de cadastro e bundles; salvar versão e ZIP sem pacotes proprietários ou segredos. Manter execução física na V100 e APK como pendências até existir evidência real.

Evidência da implementação: TypeScript e 135 testes aprovados (57 novos de descoberta), 1 teste do starter ignorado; bundles JavaScript Web/Android e introspecção Expo aprovados; revisão read-only focada em cancelamento e encadeamento aplicada. Fixtures sintéticas, sem qualquer consulta à câmera real. A descoberta não é uma confirmação de interoperabilidade física.

Entrega: push do código 26ee8be aceito em main; pacote DuoCam-descoberta-V100-codigo-fonte.zip validado com testzip e presença dos módulos de descoberta. Arquivos internos, credenciais, APKs/XAPKs e código/bibliotecas proprietários excluídos. Não houve build APK nem teste de câmera real.

## Correção nativa de TCP e sessão opcional — 5 de novembro, 22h36

- [x] **Repassar todas as opções ao VLC Android.** Corrigir e versionar os limites de initOptions e mediaOptions da dependência aberta 1.0.98; --rtsp-tcp e --no-rtsp-tcp não podem ser descartados. Instalações limpas devem aplicar o patch via lockfile, sem duplicar flags artificiais. Verificação estrutural não equivale a execução Android.
- [x] **Abrir sessão somente por escolha explícita.** No modo descoberta, oferecer controle prepareSession desativado por padrão e em cadastros existentes. Quando ativado, obter URL válida e então chamar /app/enterrecorder antes de montar o player; informar que não é somente leitura. Validar result=0 com info string, prazo/cancelamento e erros sem dados brutos ou senha. Ao parar/trocar/sair, não iniciar player por resposta tardia; não afirmar que cancelamento reverte sessão já aceita e não enviar exitrecorder ou outras alterações silenciosas.
- [x] **Preparar atualização nativa reproduzível.** Validar tipos, regressão do patch, fixtures de sessão e cancelamento, bundles e configuração; salvar código/patch/lockfile e ZIP sem segredos/pacotes proprietários. Nova compilação e teste de vídeo na câmera permanecem pendentes até evidência física.

Evidência: pnpm install --frozen-lockfile aplicou o patch e os dois limites foram conferidos no fonte Java instalado; patch plain-text sem ANSI, hash do lockfile recalculado. TypeScript e 158 testes aprovados (18 novos de sessão, 5 verificações estruturais do patch), 1 teste do starter ignorado. Bundles Web/Android e introspecção Expo aprovados; revisão read-only em cinco arquivos não encontrou defeito concreto. Nenhuma execução de Java/LibVLC corrigido no hardware.

Entrega da correção: código/patch/lockfile 8d59d3a enviados a main; ZIP DuoCam-correcao-TCP-sessao-codigo-fonte.zip verificado com testzip, patch e guia atualizados presentes, sem credenciais ou aplicativos proprietários. Metro/API com prontidão confirmada. Instalação antiga não recebe alteração Java; APK novo e reprodução física permanecem pendentes.
