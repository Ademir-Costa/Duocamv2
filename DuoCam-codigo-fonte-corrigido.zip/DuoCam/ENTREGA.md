# DuoCam — correção TCP e sessão opcional, 5 de novembro de 2026

Esta atualização sucede o código de descoberta entregue mais cedo. O app conserva dois cadastros, uma câmera ativa por vez, player VLC aberto, cadastro/persistência, mídia local, captura/gravação no celular, biblioteca e compartilhamento. Não há vídeo simulado, simultaneidade nas duas redes, proxy cloud ou incorporação de código/bibliotecas proprietários dos aplicativos enviados.

## Correção nativa concreta

A biblioteca react-native-vlc-media-player 1.0.98 descartava a última opção de inicialização e de mídia no Android. O DuoCam colocava --rtsp-tcp no último elemento e, portanto, a opção não chegava ao LibVLC. O patch versionado em patches/react-native-vlc-media-player@1.0.98.patch corrige os dois limites e é aplicado via package.json/pnpm-lock.yaml. O fonte instalado foi verificado após pnpm install --frozen-lockfile. O wrapper já reconhece RTSP como rede; não foi alterado esse comportamento.

Isso corrige um defeito de repasse confirmado; não prova que seja a única causa da tela preta. Não usamos flags falsas para contornar o problema. O patch é de biblioteca aberta, não do Veecar/Viidure.

## Sessão opcional

O usuário comprovou /app/getmediainfo com result0, rtsp://192.168.169.1, transporte tcp e port5000; comprovou /app/enterrecorder com result0/info string de sucesso. O DuoCam ainda falhou no teste manual. Port5000 continua separado da URL de vídeo como socket de mensagens no parser analisado.

Em modo Descobrir V100, o cadastro agora oferece Abertura de sessão, desativada por padrão e em dados existentes. Quando explicitamente ativada, consulta identificação/mídia e valida URL antes de enviar enterrecorder; só depois monta o VLC. Esta etapa abre modo/sessão e não é somente leitura. A resposta de sessão tem info string, diferente de info objeto da mídia. Nenhuma senha Wi-Fi é enviada como login.

Prazo e cancelamento impedem player por resposta tardia, mas não desfazem um comando já aceito no equipamento. Não enviamos exitrecorder automaticamente. Não alteramos relógio, rede, senha, resolução, gravação no cartão ou formatação. O modo manual não executa consultas ou sessão automaticamente; cadastros/URLs anteriores são preservados.

## Aplicar no telefone/tablet

A correção envolve Java: é necessário compilar e instalar um novo APK incluindo o patch. Atualizar interface/Metro/JavaScript ou repetir enterrecorder no navegador não altera a biblioteca embutida na instalação antiga. Nenhum APK foi gerado nesta etapa. Use o fluxo Android do painel Manus ou compile o ZIP fora da plataforma seguindo o guia; mantenha pnpm e o patch/lockfile. Não desinstale a versão existente sem preservar dados e mídia se houver incompatibilidade de assinatura.

Depois de instalar o build novo, conecte ao Wi-Fi real da câmera e feche a visualização de outros apps. Edite o cadastro correspondente, escolha Descobrir V100, gateway do campo Roteador (192.168.169.1 no teste), ative Abertura de sessão e escolha TCP ou Automático. Salve e toque em Conectar. No modo automático, o tcp retornado será aplicado. Não acrescente :5000 à URL de vídeo confirmada.

A Prévia e o Expo Go não têm VLC nem acessam a câmera. O indicador REPRODUZINDO ainda exige faixa de vídeo e tempo avançando, não comprova quadros visíveis. Duas redes com mesmo SSID não são unidas; a terceira unidade relatada não ganhou um terceiro cadastro nesta versão.

## Evidência e pendências

TypeScript aprovado; 158 testes aprovados e 1 teste do starter ignorado, incluindo 18 casos de sessão e 5 regressões estruturais do patch. Fonte Java instalado com ambos os laços corrigidos, patch plain-text e registro no lockfile verificados. Bundles JavaScript Web/Android e introspecção Expo aprovados. Exportação --no-bytecode contorna a arquitetura do Hermes no Sandbox e não é build APK.

A câmera respondeu às duas consultas manuais do usuário, mas não foi acessada pelo Sandbox. Ainda não há execução do Java corrigido no dispositivo, RTSP PLAY confirmado ou quadros reproduzidos. Roteamento local com dados móveis/VPN, limitações do decoder ou outras etapas do firmware podem continuar afetando o vídeo. Não foi implementado vínculo nativo forçado à rede Wi-Fi.

Detalhes: ATUALIZACAO-TCP-SESSAO.md. ATUALIZACAO-DESCOBERTA.md descreve a versão anterior, antes do patch e da opção de abertura de sessão.
