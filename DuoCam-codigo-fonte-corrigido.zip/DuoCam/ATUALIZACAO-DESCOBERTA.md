# DuoCam — descoberta de vídeo V100 (experimental)

Atualização de código de 5 de novembro de 2026. Não é um APK e não comprova vídeo funcionando na câmera física.

## O que mudou

Antes, o DuoCam tentava abrir diretamente a URL manual. Agora existe um modo **Descobrir V100**, que consulta a identificação e as informações de mídia no aparelho antes de montar o VLC. Não usa a porta 5000 como vídeo por suposição e não inventa um caminho RTSP quando a câmera não fornece um.

O formulário permite escolher descoberta ou URL manual, gateway privado e transporte RTSP Automático/TCP/UDP. Cadastros anteriores preservam nome, SSID, URL e modo manual/TCP; você precisa escolher explicitamente o modo de descoberta para testá-lo. Novos cadastros usam descoberta com gateway 192.168.169.1. A URL manual permanece salva ao mudar de modo.

A consulta é abortada ao parar, trocar de câmera ou sair da tela. Resultados tardios não iniciam um player de uma sessão encerrada. Consultar a câmera com sucesso não acende o indicador de reprodução; o monitor do VLC continua exigindo faixa de vídeo e tempo avançando. A Prévia Web e o Expo Go não tentam consultar a rede local.

## Por que essa integração foi escolhida

A análise estática do XAPK Veecar v1.0.43.260617 enviado identificou o adaptador EEASY com gateway padrão 192.168.169.1 e prefixo /app/. O roteador consulta getmediainfo antes de escolher a URL. O parser lê rtsp ou rtsps e transport; o campo port vai para um socket de mensagens, não para a porta de vídeo. Há opções TCP/UDP nos decoders do Veecar.

Referências locais de inspeção: constantes em smali_classes3/I4/m.smali (linhas 15, 33, 59, 87); consulta em smali_classes3/z5/c.smali (método queryPreviewUrl, linhas 5074–5190); mídia em smali_classes3/B5/i.smali (linhas 1494–1579). Essas referências fundamentam a hipótese de integração, mas não identificam o firmware efetivamente escolhido pelo Veecar na sua câmera. Código, bibliotecas e recursos proprietários não foram incorporados ao DuoCam nem ao ZIP.

As duas requisições implementadas são GET HTTP/80 para /app/getdeviceattr e /app/getmediainfo. Nenhum comando de alteração de relógio, rede, senha, gravação no cartão ou formatação foi implementado. A descoberta verifica result=0/info, identificação uuid e URL no mesmo gateway. Não tenta imitar uma sessão desconhecida ou enviar a senha Wi-Fi como login de vídeo.

## Como testar após compilar e instalar esta atualização

1. Conecte o celular ao Wi-Fi real da câmera no Android. Use a senha da rede já salva e mantenha a conexão mesmo sem internet. Feche a visualização do Veecar para evitar uma possível disputa por sessão.
2. No DuoCam, abra o ajuste da câmera correspondente. Informe o SSID real, não CAMERA_1/CAMERA_2 se forem apenas os nomes de exemplo.
3. Escolha **Descobrir V100 · experimental**. Confira em detalhes Wi-Fi o campo **Roteador** e use esse IPv4 como gateway; no exemplo fornecido pelo usuário, 192.168.169.1. Não use o IP do celular (192.168.169.2) nem acrescente :5000.
4. Deixe o transporte em **Automático**, salve e toque em **Conectar**. O app consultará identificação e mídia e só então abrirá o endereço recebido.
5. Se houver erro, envie o texto/código exibido pelo DuoCam e informe se o Veecar ainda mostra imagem na mesma câmera. Não é necessário compartilhar senha, token ou captura completa do tráfego. Se a consulta funcionar mas o player falhar, o diagnóstico informa protocolo/host/porta e transporte sem caminho, query ou credenciais.

O modo automático segue TCP/UDP reconhecido na resposta; na ausência desses valores, o VLC negocia. Os modos explícitos não são testados silenciosamente em sequência. Pode ser necessário confirmar o transporte no firmware; não recomendamos portas aleatórias como solução.

## Limites importantes

Há dois cadastros e somente uma câmera ativa por vez; as três unidades relatadas não foram cadastradas automaticamente. Wi-Fi conectado não garante que cada app consiga alcançar a câmera: roteamento local com dados móveis/VPN e restrições do fabricante ainda podem afetar o acesso. Este código não implementa vínculo nativo forçado do processo à rede Wi-Fi.

Caso o firmware exija autenticação, sessão prévia, cookies obrigatórios, comandos de inicialização, endpoint diferente ou decoder proprietário, a consulta experimental pode falhar. A URL com usuário/senha é rejeitada nesta versão. Não foi demonstrado um login RTSP separado nem que a senha Wi-Fi sirva para ele.

HTTP/RTSP comuns não criptografam a comunicação; use câmeras e redes de confiança. O conteúdo das consultas não é enviado à nuvem nem registrado em logs pelo módulo de descoberta. Credenciais, identificadores e respostas brutas não aparecem no diagnóstico de tela.

## Verificação e entrega

TypeScript aprovado e 135 testes determinísticos aprovados, com 1 teste do starter ignorado. Destes, 57 casos novos verificam envelope, identidade, seleção de canal, separação de portas, gateway, URL, transporte, falhas HTTP/JSON, prazo, cancelamento e migração de cadastro. As respostas de teste são sintéticas, não capturadas da câmera.

Compilar o código atualizado pelo fluxo Android do painel Manus e instalar o novo resultado. Uma instalação anterior não recebe esta atualização automaticamente. Nenhum APK foi gerado nesta etapa. Bundles JavaScript Web/Android e introspecção Expo foram aprovados; a exportação usou --no-bytecode pela diferença de arquitetura do Hermes instalado no Sandbox e não substitui build Android nem teste de câmera física. A revisão read-only orientou isolar a mensagem informativa da Prévia/Expo Go para não montar um componente de player com URL vazia; o ajuste foi aplicado.
