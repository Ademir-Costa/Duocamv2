# DuoCam — plano de implementação

## Direção escolhida

O pedido original é recriar as funções do Viidure em um novo app com duas telas de visualização para duas câmeras Wi-Fi. O usuário informou duas VT-100 com redes Wi-Fi próprias e aceitou a melhor opção técnica. A solução recomendada é manter nomes diferentes, cadastrar as duas câmeras e visualizar **uma câmera ao vivo por vez**, com troca explícita. Dois nomes Wi-Fi iguais não unificam os pontos de acesso.

A versão inicial será um aplicativo Android original, não um APK modificado do Viidure. A análise estática confirmou uso de RTSP em algumas famílias suportadas pelo original, mas não confirmou o protocolo, IP, URL, comandos ou chipset das VT-100. A compatibilidade com essas câmeras ainda depende de documentação ou teste no equipamento. Não haverá vídeos simulados apresentados como ao vivo.

## Funcionalidades e limites

A tela principal terá dois painéis identificados como Câmera 1 e Câmera 2, com estado independente, seleção de câmera e ampliação. Só um player ficará ativo no modo de redes independentes. Selecionar outra câmera encerrará o player anterior. O app abrirá os ajustes Wi-Fi do Android; depois da escolha da rede correta, o usuário retornará e iniciará a conexão. Não será prometida troca silenciosa de Wi-Fi.

Cada câmera poderá ter nome, identificação da rede e URL de vídeo editáveis e salvos localmente. A URL será fornecida pelo usuário/fabricante, sem tratar endpoints vistos em outros adaptadores como se fossem confirmados para a VT-100. Senhas não serão exibidas em logs. O usuário escolherá a rede pelo próprio Android.

O player nativo será baseado em biblioteca aberta com suporte RTSP e HTTP. O aplicativo mostrará estados reais de conexão, reprodução e erro, permitirá silenciar áudio, parar/reconectar e ampliar a imagem. Fotos de um quadro e gravação **local do stream recebido** serão implementadas nos players nativos que exponham essas operações. Gravação local no celular não equivale a iniciar/parar a gravação no cartão da câmera.

Haverá biblioteca local para fotos e gravações criadas, com reprodução e compartilhamento. Download direto será oferecido para uma URL de arquivo de mídia informada, sem fingir listar o cartão da câmera. O app não enviará os vídeos a um servidor externo.

Reprodução do cartão, listagem remota, iniciar/parar gravação no equipamento, parâmetros OEM e formatação do cartão permanecem dependentes do protocolo/SDK da VT-100. Edição avançada, AR/IA, GPS e serviços pagos do Viidure não serão considerados copiados nem entregues nesta primeira versão. Não serão criados botões que simulem essas funções. A recriação integral dessas funcionalidades exige escopo separado e integrações documentadas.

A prévia Web servirá para revisar interface, cadastro e fluxos. Ela não verifica redes locais do telefone nem reprodução RTSP. Expo Go não inclui o módulo VLC: o uso de RTSP, captura e gravação exigirá build nativo. O app exibirá esse limite claramente.

## Implementação e dependências

Manter o starter Expo Router / React Native / TypeScript / NativeWind gerado pelo projeto. Usar biblioteca react-native-vlc-media-player com plugin Expo, respeitando sua licença e mantendo o módulo isolado do Web e do Expo Go. Usar expo-video para reprodução local/HTTP compatível, expo-file-system para arquivos locais, expo-sharing para compartilhamento e AsyncStorage para configurações e índice de mídia. Não copiar bibliotecas, assets, código, marca, assinaturas ou traduções do Viidure.

O app conectará diretamente ao endpoint da câmera na rede local do telefone; o servidor cloud não tentará buscar IPs privados do usuário. Não requer login para ver câmeras ou guardar arquivos localmente. Os listeners existentes Metro 8081 e API 3000 serão preservados. O esquema inicial do starter será sincronizado antes do primeiro tráfego OAuth/API, se usado.

## Estrutura do projeto

- `app/(tabs)/`: telas de visualização, biblioteca local e ajustes/ajuda.
- `app/camera/`: cadastro e detalhe de cada uma das duas câmeras.
- `components/camera/`: painéis, player nativo, fronteira Web e controles de sessão.
- `components/duocam/`: cabeçalhos, botões, mensagens e identidade visual reutilizáveis.
- `lib/cameras/`: tipos, validação de URLs, estado de conexão e armazenamento local.
- `lib/media/`: gerenciamento de arquivos locais, índice da biblioteca e downloads.
- `tests/`: cobertura determinística de regras de sessão única, validação e persistência.
- `assets/images/`: ícone e marca originais do DuoCam.
- `server/` e `drizzle/`: preservar infraestrutura do starter, sem proxy de vídeo de rede privada.

## Aparência

Três direções consideradas: console instrumental noturno com acento âmbar (p=0,06); utilitário suíço claro com acento ultramarino (p=0,04); ferramenta industrial verde-cinza (p=0,03). Seleção: **console instrumental noturno**, apropriado para monitoramento veicular, sem copiar o Viidure.

**Movimento:** design industrial de instrumentos com hierarquia funcional modernista. **Princípios:** foco na imagem; estado visível e verdadeiro; controles de toque amplos; baixo ruído visual. **Cores:** grafite e superfícies azul-acinzentadas reduzem distração; âmbar identifica a câmera selecionada; verde apenas quando a reprodução realmente começar; vermelho em erros e gravação confirmada.

**Layout:** composição vertical para uma mão, título compacto, seletor de duas câmeras e dois painéis empilhados; no detalhe, um painel maior com controles e informações de conexão. Não usar um dashboard cheio de métricas fictícias.

**Elementos característicos:** índices 01/02 monoespaçados, cantos discretamente recortados e duas molduras de visor no símbolo. **Interação:** cada ação mostra resultado ou erro real; seleção de câmera interrompe a anterior antes de iniciar outra. **Animação:** transições curtas de opacidade e realce entre 120 e 180 ms; sem piscadas ou animações que sugiram um stream inexistente.

**Tipografia:** fonte de interface nativa com títulos semibold e rótulos técnicos monoespaçados; título 28–32, seções 18–20, texto 14–16, indicadores 11–12. **Essência:** duas câmeras organizadas, uma conexão confiável por vez. Personalidade: direta, técnica, cuidadosa.

**Voz:** português brasileiro simples, sem promessas de conexão automática. Exemplos: “Escolha o Wi-Fi da câmera e volte ao app.” e “Aguardando vídeo. Confira a rede e o endereço.” **Marca:** DuoCam com símbolo de dois visores e um ponto de seleção; ícone quadrado sem cantos arredondados embutidos. **Cor de assinatura:** âmbar #F4B545.

## Entrega e compilação Android

Entregar código original salvo em uma versão do projeto, interface revisável na Prévia, verificações TypeScript e regras de sessão. Preparar permissões mínimas, tráfego local e plugin nativo para compilação Android pelo painel Manus. Não compilar um APK de release dentro do Sandbox nem afirmar que um APK existe antes do resultado real de build. A compatibilidade de VLC com a versão atual do React Native e o funcionamento nas VT-100 precisam de build/dispositivo real. A entrega inicial distinguirá claramente o que está implementado, o que requer build e o que depende do equipamento.

## Correção pontual — 4 de novembro de 2026

O usuário corrigiu o modelo para V100 e relatou painel conectado/ao vivo sem imagem ao tentar rtsp://192.168.169.1:5000. Corrigir o indicador: onPlaying e eventos de progresso isolados não devem confirmar vídeo nem cancelar o prazo de conexão. Exigir faixa de vídeo com dimensões válidas e avanço do tempo do player, mostrar REPRODUZINDO em vez de afirmar que pixels visíveis foram comprovados e detectar estagnação. Essa evidência do player não prova decodificação/apresentação de quadros no aparelho. Ao esgotar o prazo, mostrar ausência de confirmação de vídeo e impedir eventos tardios de restaurar o estado. Preservar sessão única, ações de captura e fonte configurável. Corrigir também o rótulo V100 e a quebra de linha literal observada no cadastro. Não fixar 5000, descobrir endpoints por suposição ou mudar senha/rede.

## Integração de descoberta Veecar — 5 de novembro de 2026

O usuário forneceu o XAPK Veecar que exibe vídeo nas V100. A inspeção local do pacote confirma a família EEASY com gateway padrão 192.168.169.1, consultas de controle HTTP/80 /app/getdeviceattr e /app/getmediainfo; o parser lê info.rtsps ou info.rtsp, transport e port, sendo port de mensagens, não a porta RTSP. Esse fluxo dá base para uma integração experimental independente, mas não confirma a família/firmware de cada câmera do usuário. Não copiar código, assets ou bibliotecas proprietárias.

Adicionar lib/cameras/discovery.ts para duas consultas GET somente leitura executadas diretamente no celular, com gateway IPv4 privado editável, prazo por consulta, cancelamento e validação rigorosa de respostas e URL no mesmo gateway. Não sincronizar relógio, alterar senha, iniciar gravação no cartão ou invocar comandos OEM. Não inventar URL fallback nem tratar port como vídeo. O envelope esperado é result inteiro 0 e info objeto; atributos precisam identificar uuid. rtsps usa curcamid da câmera (não o índice 1/2 do cadastro de câmeras independentes); rtsp é a alternativa. URLs com credenciais ou destino externo são rejeitadas nesta versão, com mensagem explícita. Sessão exigida pelo firmware continuará pendente; não há login confirmado a reproduzir.

Adicionar components/camera/connected-player.tsx como fronteira de resolução: descobrir antes de montar VLC, abortar ao parar/trocar/sair, ignorar resultados tardios; Web e Expo Go não acessam a rede local. No cadastro, escolher Descobrir V100 (experimental) ou URL manual, gateway e transporte Automático/TCP/UDP. Preservar URL e nomes existentes; cadastros legados permanecem no modo manual para não mudar silenciosamente sua conexão. Novos cadastros usam descoberta. O modo automático segue tcp/udp se reconhecido na resposta, caso contrário deixa negociação VLC; não pressupor que TCP é obrigatório. Diagnóstico em tela sem senha/token/identificador, distinguindo consulta bem-sucedida de vídeo confirmado pelo monitor existente. Manter dois painéis e uma sessão ativa, mesmo com três câmeras relatadas; ampliação do número de cadastros não faz parte desta correção.

Preparar código atualizado, testes sem câmera real e ZIP sem segredos. Gerar APK pelo fluxo Android do painel, não dentro do Sandbox. Descoberta e reprodução físicas precisam de build e teste; sucesso em fixtures não equivale a conexão com a V100.

## Correção concreta do transporte VLC — 5 de novembro, 22h36

A câmera respondeu à consulta getmediainfo com result=0, rtsp=rtsp://192.168.169.1, transport=tcp e port=5000; respondeu a enterrecorder com result=0/info string de sucesso. Mesmo após o teste manual, o DuoCam mostra falha genérica, sem log técnico do RTSP. Não afirmar que abrir a sessão basta para produzir imagem.

Foi encontrado defeito reproduzível na biblioteca aberta react-native-vlc-media-player 1.0.98: os laços Java de initOptions e mediaOptions usam i < options.size()-1. Na lista DuoCam, --rtsp-tcp é a última opção e não chega ao LibVLC. Corrigir ambos os limites com patch pnpm versionado e lockfile atualizado, sem modificar código proprietário ou acrescentar flags falsas. Verificar que o wrapper já identifica fonte de rede antes de duplicar isNetwork. Testar regressão diretamente no fonte Java instalado, no patch versionado e nas listas de transporte. Essa validação estrutural não é uma execução do player Android.

Adicionar abertura de sessão EEASY opcional no modo descoberta: prepareSession boolean, desativado por padrão e em dados existentes para preservar a política somente leitura; controle explícito no cadastro explica que /app/enterrecorder abre sessão/modo de visualização. Executar depois de obter URL válida e antes do player, somente quando usuário ativar. Aceitar result inteiro0/info string (não o envelope info objeto da mídia), prazo/cancelamento, sem senha/cookies/comandos adicionais. Não prometer que cancelar desfaça um comando já aceito; não chamar exitrecorder automaticamente porque pode interferir em sessão de outro app e não foi testado. Continuar uma única sessão e ignorar resultados tardios.

Entregar código/ZIP com patch reproduzível e guia de nova compilação. Não gerar APK no Sandbox nem declarar reprodução física corrigida sem evidência da instalação nova.
