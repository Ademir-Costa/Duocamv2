import { Ionicons } from "@expo/vector-icons";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import type { ComponentProps, ReactNode } from "react";
export const C = {
  bg: "#10141B",
  surface: "#1B222D",
  raised: "#252F3D",
  line: "#303B4B",
  text: "#F2F4F7",
  muted: "#8D99AB",
  amber: "#F4B545",
  green: "#64D6A0",
  red: "#F47C7C",
};
export type IconName = ComponentProps<typeof Ionicons>["name"];
export function Brand({ small = false }: { small?: boolean }) {
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 9 }}>
      <View style={s.mark}>
        <View style={s.lens1} />
        <View style={s.lens2} />
      </View>
      <Text
        style={{
          color: C.text,
          fontSize: small ? 21 : 25,
          fontWeight: "700",
          letterSpacing: -0.8,
        }}
      >
        duo<Text style={{ color: C.amber }}>cam</Text>
      </Text>
    </View>
  );
}
export function Eyebrow({ children }: { children: ReactNode }) {
  return <Text style={s.eyebrow}>{children}</Text>;
}
export function Button({
  title,
  icon,
  onPress,
  disabled,
  variant = "primary",
  style,
}: {
  title: string;
  icon?: IconName;
  onPress: () => void;
  disabled?: boolean;
  variant?: "primary" | "secondary" | "danger";
  style?: StyleProp<ViewStyle>;
}) {
  const fg =
    variant === "primary" ? C.bg : variant === "danger" ? C.red : C.text;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      accessibilityState={{ disabled: !!disabled }}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        s.button,
        {
          backgroundColor: variant === "primary" ? C.amber : C.raised,
          opacity: disabled ? 0.4 : pressed ? 0.72 : 1,
        },
        style,
      ]}
    >
      {icon && <Ionicons name={icon} size={19} color={fg} />}
      <Text style={{ color: fg, fontSize: 14, fontWeight: "700" }}>
        {title}
      </Text>
    </Pressable>
  );
}
export function IconButton({
  icon,
  label,
  onPress,
  disabled,
}: {
  icon: IconName;
  label: string;
  onPress: () => void;
  disabled?: boolean;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        s.iconButton,
        { opacity: disabled ? 0.35 : pressed ? 0.6 : 1 },
      ]}
    >
      <Ionicons name={icon} color={C.text} size={21} />
    </Pressable>
  );
}
export function Notice({
  children,
  danger = false,
}: {
  children: ReactNode;
  danger?: boolean;
}) {
  return (
    <View style={[s.notice, danger && { borderColor: C.red }]}>
      <Ionicons
        name={danger ? "alert-circle-outline" : "information-circle-outline"}
        size={19}
        color={danger ? C.red : C.amber}
      />
      <Text
        style={{
          flex: 1,
          color: danger ? C.red : C.muted,
          fontSize: 13,
          lineHeight: 20,
        }}
      >
        {children}
      </Text>
    </View>
  );
}
export const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: C.bg },
  content: {
    width: "100%",
    maxWidth: 720,
    alignSelf: "center",
    paddingHorizontal: 22,
    paddingBottom: 28,
    gap: 22,
  },
  title: {
    color: C.text,
    fontSize: 30,
    fontWeight: "700",
    letterSpacing: -0.8,
  },
  body: { color: C.muted, fontSize: 14, lineHeight: 22 },
  section: { color: C.text, fontSize: 18, fontWeight: "600" },
  label: {
    color: C.muted,
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 0.5,
  },
  input: {
    backgroundColor: C.surface,
    borderWidth: 1,
    borderColor: C.line,
    color: C.text,
    borderRadius: 12,
    padding: 16,
    fontSize: 15,
  },
  card: {
    backgroundColor: C.surface,
    borderRadius: 16,
    padding: 20,
    gap: 14,
    borderWidth: 1,
    borderColor: C.line,
  },
});
const s = StyleSheet.create({
  mark: { width: 29, height: 32 },
  lens1: {
    position: "absolute",
    top: 2,
    left: 0,
    width: 22,
    height: 15,
    borderWidth: 2,
    borderColor: C.amber,
    borderRadius: 3,
  },
  lens2: {
    position: "absolute",
    bottom: 1,
    right: 0,
    width: 22,
    height: 15,
    borderWidth: 2,
    borderColor: C.amber,
    borderRadius: 3,
  },
  eyebrow: {
    color: C.muted,
    fontSize: 11,
    letterSpacing: 2,
    fontWeight: "600",
  },
  button: {
    minHeight: 48,
    borderRadius: 12,
    paddingHorizontal: 18,
    paddingVertical: 13,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  iconButton: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    backgroundColor: C.raised,
  },
  notice: {
    flexDirection: "row",
    gap: 10,
    alignItems: "flex-start",
    padding: 15,
    backgroundColor: C.surface,
    borderWidth: 1,
    borderColor: C.line,
    borderRadius: 12,
  },
});
