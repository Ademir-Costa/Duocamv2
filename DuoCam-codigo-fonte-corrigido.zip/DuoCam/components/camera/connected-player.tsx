import { forwardRef, useEffect, useState } from "react";
import { ActivityIndicator, Text, View } from "react-native";
import { C } from "@/components/duocam/ui";
import {
  cameraGateway,
  cameraMode,
  cameraTransport,
  validateStreamUrl,
  type Camera,
} from "@/lib/cameras/model";
import {
  DiscoveryError,
  streamSummary,
  type DiscoveredStream,
} from "@/lib/cameras/discovery";
import { discoverConnection } from "@/lib/cameras/connection";
import LivePlayer, { hasNativePlayer } from "./live-player";
import type { PlayerHandle, PlayerProps } from "./player-types";

type Props = Omit<PlayerProps, "uri" | "transport"> & {
  camera: Camera;
  onDiagnostic: (message: string) => void;
};
const ConnectedPlayer = forwardRef<PlayerHandle, Props>(
  function ConnectedPlayer(
    { camera, onDiagnostic, onStatus, ...playerProps },
    ref,
  ) {
    const mode = cameraMode(camera);
    const gateway = cameraGateway(camera);
    const transport = cameraTransport(camera);
    const uri = camera.url;
    const prepareSession = camera.prepareSession === true;
    const [stream, setStream] = useState<DiscoveredStream | null>(null);
    const [stage, setStage] = useState("Consultando identificação da câmera…");
    const [failed, setFailed] = useState(false);
    useEffect(() => {
      const controller = new AbortController();
      let alive = true;
      setStream(null);
      setFailed(false);
      // Preview and Expo Go must not probe the phone's local network.
      if (!hasNativePlayer()) {
        onStatus(
          "error",
          "Descoberta e reprodução precisam do APK Android com VLC. A Prévia e o Expo Go não consultam a câmera.",
        );
        return () => controller.abort();
      }
      if (mode === "manual") {
        const issue = validateStreamUrl(uri);
        if (issue) {
          setFailed(true);
          setStage("URL manual inválida.");
          onStatus("error", issue);
          return () => controller.abort();
        }
        setStream({ uri, transport, channel: 0 });
        onDiagnostic(
          "URL manual. O acesso ao Wi-Fi e a reprodução são etapas diferentes.",
        );
        return () => controller.abort();
      }
      onStatus("connecting");
      setStage("Consultando identificação da câmera…");
      onDiagnostic(
        prepareSession
          ? "Descoberta V100: a abertura de sessão será enviada por sua escolha; não é apenas leitura."
          : "Descoberta V100 experimental: consultas somente leitura.",
      );
      discoverConnection({
        gateway,
        prepareSession,
        signal: controller.signal,
        onStage: (step) => {
          if (alive && !controller.signal.aborted)
            setStage(
              step === "device"
                ? "Consultando identificação da câmera…"
                : step === "media"
                  ? "Solicitando endereço de vídeo…"
                  : "Abrindo sessão de visualização…",
            );
        },
      })
        .then((result) => {
          if (!alive || controller.signal.aborted) return;
          const resolved = {
            ...result,
            transport: transport === "auto" ? result.transport : transport,
          };
          setStream(resolved);
          onDiagnostic(
            `${prepareSession ? "Sessão aceita" : "Consulta concluída"}: ${streamSummary(resolved)}. Aguardando confirmação de reprodução pelo player.`,
          );
        })
        .catch((error: unknown) => {
          if (!alive || controller.signal.aborted) return;
          setFailed(true);
          const detail =
            error instanceof DiscoveryError
              ? `[${error.code}] ${error.message}`
              : "Falha na descoberta. Nenhuma URL foi presumida.";
          setStage("Não foi possível descobrir o vídeo.");
          onStatus("error", detail);
        });
      return () => {
        alive = false;
        controller.abort();
      };
    }, [mode, gateway, transport, uri, prepareSession, onDiagnostic, onStatus]);
    if (!hasNativePlayer())
      return (
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            padding: 24,
            gap: 12,
          }}
        >
          <Text style={{ color: C.amber, fontSize: 16, textAlign: "center" }}>
            Vídeo no aplicativo Android
          </Text>
          <Text style={{ color: C.muted, fontSize: 13, textAlign: "center" }}>
            A Prévia e o Expo Go não incluem VLC. Nenhuma consulta à rede da
            câmera ou imagem simulada é executada aqui.
          </Text>
        </View>
      );
    if (!stream)
      return (
        <View
          style={{
            flex: 1,
            justifyContent: "center",
            alignItems: "center",
            padding: 24,
            gap: 14,
          }}
        >
          {!failed && <ActivityIndicator color={C.amber} size="large" />}
          <Text
            style={{
              color: failed ? C.red : C.muted,
              textAlign: "center",
              fontSize: 13,
            }}
          >
            {stage}
          </Text>
          <Text style={{ color: C.muted, textAlign: "center", fontSize: 11 }}>
            Consulta de rede não confirma imagem. Nenhum vídeo simulado.
          </Text>
        </View>
      );
    return (
      <LivePlayer
        {...playerProps}
        ref={ref}
        uri={stream.uri}
        transport={stream.transport}
        onStatus={onStatus}
      />
    );
  },
);
export default ConnectedPlayer;
