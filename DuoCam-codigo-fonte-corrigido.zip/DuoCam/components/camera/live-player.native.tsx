import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
} from "react";
import { Text, UIManager, View } from "react-native";
import type { VLCPlayer as VlcClass } from "react-native-vlc-media-player";
import { C } from "@/components/duocam/ui";
import { nativeFileUri } from "@/lib/cameras/native-path";
import { PlaybackMonitor } from "@/lib/cameras/playback-monitor";
import { vlcOptions } from "@/lib/cameras/discovery";
import type { PlayerHandle, PlayerProps } from "./player-types";
export function hasNativePlayer(): boolean {
  try {
    return !!UIManager.getViewManagerConfig("RCTVLCPlayer");
  } catch {
    return false;
  }
}
const NativeVlc: typeof VlcClass | null = (() => {
  if (!hasNativePlayer()) return null;
  const Base: typeof VlcClass =
    require("react-native-vlc-media-player").VLCPlayer;
  // The base constructor binds this method; override it to forward failures too.
  return class VlcWithSnapshotErrors extends Base {
    _onSnapshot(event: {
      nativeEvent: { success: boolean; path?: string; error?: string };
    }) {
      this.props.onSnapshot?.(event.nativeEvent);
    }
  };
})();
const LivePlayer = forwardRef<PlayerHandle, PlayerProps>(function LivePlayer(
  { uri, muted, transport = "auto", onStatus, onSnapshot, onRecordingCreated },
  ref,
) {
  const player = useRef<VlcClass>(null);
  const monitor = useRef(new PlaybackMonitor(Date.now()));
  const alive = useRef(false);
  const published = useRef("");
  const source = useMemo(
    () => ({
      uri,
      initType: 2 as const,
      initOptions: vlcOptions(transport),
    }),
    [uri, transport],
  );
  function publish() {
    if (!alive.current) return;
    const state = monitor.current.snapshot();
    const signature = `${state.status}:${state.detail ?? ""}`;
    if (signature === published.current) return;
    published.current = signature;
    onStatus(state.status, state.detail);
  }
  function fail(detail: string) {
    if (!alive.current) return;
    monitor.current.fail(detail);
    publish();
    try {
      player.current?.stopPlayer();
    } catch {
      // Preserve the diagnostic even if the native player is already stopped.
    }
  }
  useImperativeHandle(
    ref,
    () => ({
      snapshot(path) {
        if (!player.current) throw new Error("Player nativo indisponível.");
        player.current.snapshot(path.replace(/^file:\/\//, ""));
      },
      startRecording(directory) {
        if (!player.current) throw new Error("Player nativo indisponível.");
        player.current.startRecording(directory.replace(/^file:\/\//, ""));
      },
      stopRecording() {
        if (!player.current) throw new Error("Player nativo indisponível.");
        player.current.stopRecording();
      },
    }),
    [],
  );
  useEffect(() => {
    alive.current = true;
    monitor.current = new PlaybackMonitor(Date.now());
    published.current = "";
    if (!NativeVlc) {
      fail(
        "Expo Go não inclui este player. Gere e instale o APK Android pelo painel para testar com sua câmera.",
      );
      return () => {
        alive.current = false;
      };
    }
    publish();
    const watchdog = setInterval(() => {
      monitor.current.tick(Date.now());
      publish();
      if (monitor.current.snapshot().status === "error") {
        clearInterval(watchdog);
        try {
          player.current?.stopPlayer();
        } catch {
          /* Error already reported. */
        }
      }
    }, 1000);
    return () => {
      alive.current = false;
      clearInterval(watchdog);
      monitor.current.stop();
    };
  }, [uri, onStatus]);
  if (!NativeVlc)
    return (
      <View style={{ flex: 1, padding: 24, justifyContent: "center" }}>
        <Text style={{ color: C.amber, textAlign: "center", fontSize: 15 }}>
          O player RTSP precisa de um APK compilado. Ele não está incluído no
          Expo Go.
        </Text>
      </View>
    );
  return (
    <NativeVlc
      ref={player}
      style={{ width: "100%", height: "100%" }}
      source={source}
      muted={muted}
      autoplay
      playInBackground={false}
      videoAspectRatio="16:9"
      resizeMode="contain"
      acceptInvalidCertificates={false}
      // Playing alone can indicate an audio stream or a player state, not video.
      onLoad={(event) => {
        if (!alive.current) return;
        monitor.current.noteVideo(event.videoSize, Date.now());
        publish();
      }}
      onProgress={(event) => {
        if (!alive.current) return;
        monitor.current.noteProgress(event.currentTime, Date.now());
        publish();
      }}
      onBuffering={() => {
        if (!alive.current) return;
        monitor.current.buffering();
        publish();
      }}
      onError={() =>
        fail(
          "O player informou falha. Confira a rede, o endereço e se a câmera exige uma sessão própria antes do vídeo.",
        )
      }
      onStopped={() => {
        if (!alive.current) return;
        monitor.current.stop();
        publish();
      }}
      onEnd={() => fail("A transmissão foi encerrada pela câmera.")}
      onSnapshot={(event) => {
        if (!alive.current) return;
        try {
          onSnapshot({
            ...event,
            path: event.path ? nativeFileUri(event.path) : undefined,
          });
        } catch {
          onSnapshot({
            success: false,
            error: "O player retornou um caminho de foto inválido.",
          });
        }
      }}
      onRecordingCreated={(path) => {
        if (!alive.current) return;
        try {
          onRecordingCreated(nativeFileUri(path));
        } catch {
          onRecordingCreated("");
        }
      }}
    />
  );
});
export default LivePlayer;
