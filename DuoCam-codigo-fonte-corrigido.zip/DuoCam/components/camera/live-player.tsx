import { forwardRef, useEffect } from "react";
import { Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { C } from "@/components/duocam/ui";
import type { PlayerHandle, PlayerProps } from "./player-types";
export function hasNativePlayer() {
  return false;
}
const LivePlayer = forwardRef<PlayerHandle, PlayerProps>(function LivePlayer(
  { onStatus },
  _ref,
) {
  useEffect(() => {
    onStatus(
      "error",
      "O vídeo RTSP precisa do app Android compilado. A Prévia não se conecta ao Wi-Fi do seu celular.",
    );
  }, [onStatus]);
  return (
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        padding: 25,
        gap: 12,
      }}
    >
      <Ionicons name="phone-portrait-outline" size={34} color={C.amber} />
      <Text style={{ color: C.text, fontSize: 16, fontWeight: "600" }}>
        Vídeo no aplicativo Android
      </Text>
      <Text
        style={{
          color: C.muted,
          fontSize: 13,
          lineHeight: 20,
          textAlign: "center",
        }}
      >
        A Prévia permite configurar e conhecer o app. Não é uma transmissão ao
        vivo.
      </Text>
    </View>
  );
});
export default LivePlayer;
