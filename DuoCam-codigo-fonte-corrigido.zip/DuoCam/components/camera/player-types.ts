import type { SessionStatus, RtspTransport } from "@/lib/cameras/model";
export type PlayerHandle = {
  snapshot: (path: string) => void;
  startRecording: (directory: string) => void;
  stopRecording: () => void;
};
export type PlayerProps = {
  uri: string;
  muted: boolean;
  transport?: RtspTransport;
  onStatus: (status: SessionStatus, error?: string) => void;
  onSnapshot: (event: {
    success: boolean;
    path?: string;
    error?: string;
  }) => void;
  onRecordingCreated: (path: string) => void;
};
