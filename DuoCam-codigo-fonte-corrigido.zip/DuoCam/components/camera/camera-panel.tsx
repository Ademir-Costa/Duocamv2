import { Ionicons } from "@expo/vector-icons";
import { Pressable, StyleSheet, Text, View } from "react-native";
import type { ReactNode } from "react";
import {
  cameraMode,
  type Camera,
  type SessionStatus,
} from "@/lib/cameras/model";
import { Button, C, IconButton } from "@/components/duocam/ui";
export function CameraPanel({
  camera,
  selected,
  status,
  children,
  onSelect,
  onEdit,
  onExpand,
  onConnect,
  error,
}: {
  camera: Camera;
  selected: boolean;
  status: SessionStatus;
  children?: ReactNode;
  onSelect: () => void;
  onEdit: () => void;
  onExpand: () => void;
  onConnect: () => void;
  error?: string | null;
}) {
  const discovery = cameraMode(camera) === "discovery";
  const configured = discovery || !!camera.url;
  const label =
    status === "playing"
      ? "REPRODUZINDO"
      : status === "connecting"
        ? "AGUARDANDO VÍDEO"
        : status === "error"
          ? "SEM VÍDEO"
          : selected
            ? "SELECIONADA"
            : "EM ESPERA";
  const color =
    status === "playing"
      ? C.green
      : status === "error"
        ? C.red
        : selected
          ? C.amber
          : C.muted;
  return (
    <View style={[s.panel, selected && { borderColor: C.amber }]}>
      <View style={s.header}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Selecionar ${camera.name}`}
          onPress={onSelect}
          style={{
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
          }}
        >
          <Text
            style={{
              color: selected ? C.amber : C.muted,
              fontSize: 23,
              fontFamily: "monospace",
            }}
          >
            0{camera.id}
          </Text>
          <View style={{ flex: 1 }}>
            <Text style={{ color: C.text, fontSize: 15, fontWeight: "600" }}>
              {camera.name}
            </Text>
            <Text
              style={{ color: C.muted, fontSize: 11, marginTop: 4 }}
              numberOfLines={1}
            >
              {camera.ssid || "Rede não configurada"}
            </Text>
          </View>
        </Pressable>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
          <View
            style={{
              width: 5,
              height: 5,
              borderRadius: 3,
              backgroundColor: color,
            }}
          />
          <Text
            style={{
              color,
              fontSize: 9,
              fontWeight: "700",
              letterSpacing: 0.7,
            }}
          >
            {label}
          </Text>
        </View>
      </View>
      <View style={s.video}>
        {children || (
          <View style={s.empty}>
            <Ionicons
              name={selected ? "videocam-outline" : "pause-circle-outline"}
              size={36}
              color={selected ? C.amber : C.line}
            />
            <Text
              style={{
                color: C.text,
                fontSize: 14,
                fontWeight: "600",
                marginTop: 12,
              }}
            >
              {selected ? "Pronta para conectar" : "Uma conexão por vez"}
            </Text>
            <Text
              style={{
                color: C.muted,
                fontSize: 12,
                lineHeight: 18,
                textAlign: "center",
                marginTop: 6,
              }}
            >
              {selected
                ? discovery
                  ? "Conecte ao Wi-Fi e consulte o vídeo da câmera."
                  : camera.url
                    ? "Escolha o Wi-Fi desta câmera no Android."
                    : "Configure descoberta ou URL manual para começar."
                : "Selecione esta câmera para trocar a visualização."}
            </Text>
          </View>
        )}
        <View
          pointerEvents="none"
          style={[
            s.corner,
            { left: 12, top: 12, borderLeftWidth: 1, borderTopWidth: 1 },
          ]}
        />
        <View
          pointerEvents="none"
          style={[
            s.corner,
            {
              right: 12,
              bottom: 12,
              borderRightWidth: 1,
              borderBottomWidth: 1,
            },
          ]}
        />
      </View>
      {error && selected && (
        <Text
          style={{
            color: C.red,
            fontSize: 12,
            lineHeight: 18,
            paddingHorizontal: 16,
            paddingTop: 12,
          }}
        >
          {error}
        </Text>
      )}
      <View style={s.footer}>
        <Button
          title={
            configured ? (selected ? "Conectar" : "Selecionar") : "Configurar"
          }
          icon={configured ? "wifi-outline" : "add-outline"}
          variant={selected ? "primary" : "secondary"}
          onPress={configured ? (selected ? onConnect : onSelect) : onEdit}
          style={{ flex: 1, minHeight: 42 }}
        />
        <IconButton
          icon="options-outline"
          label={`Editar ${camera.name}`}
          onPress={onEdit}
        />
        <IconButton
          icon="expand-outline"
          label={`Ampliar ${camera.name}`}
          onPress={onExpand}
          disabled={!selected}
        />
      </View>
    </View>
  );
}
const s = StyleSheet.create({
  panel: {
    overflow: "hidden",
    borderRadius: 16,
    backgroundColor: C.surface,
    borderColor: C.line,
    borderWidth: 1,
  },
  header: { padding: 16, flexDirection: "row", alignItems: "center", gap: 10 },
  video: { aspectRatio: 16 / 9, backgroundColor: "#080B10" },
  empty: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  footer: { flexDirection: "row", gap: 8, padding: 12 },
  corner: {
    position: "absolute",
    width: 16,
    height: 16,
    borderColor: "#536071",
  },
});
