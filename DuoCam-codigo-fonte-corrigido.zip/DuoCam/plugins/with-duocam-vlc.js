const { withAppBuildGradle } = require("@expo/config-plugins");

// The upstream optional Android plugin anchors on the pre-RN-0.71 template.
// Append a guarded task instead, leaving native autolinking to Expo.
const marker = "// DUOCAM_VLC_NATIVE_LIBS";
const nativeLibraries = `
${marker}
tasks.configureEach { task ->
    if (task.name.contains('merge') && task.name.endsWith('NativeLibs')) {
        task.doFirst {
            if (task.hasProperty('externalLibNativeLibs')) {
                task.externalLibNativeLibs.files.findAll { file ->
                    file.toString().contains('jetified-react-android') || file.toString().contains('jetified-react-native')
                }.each { directory ->
                    if (directory.exists()) {
                        project.fileTree(directory).matching { include '**/libc++_shared.so' }.files.each { duplicate ->
                            if (!duplicate.delete()) {
                                throw new GradleException('DuoCam: cannot remove duplicate React Native libc++_shared.so')
                            }
                        }
                    }
                }
            }
        }
    }
}
`;
module.exports = function withDuoCamVlc(config) {
  return withAppBuildGradle(config, (mod) => {
    if (mod.modResults.language !== "groovy")
      throw new Error("O plugin DuoCam VLC requer o template Android Groovy.");
    if (!mod.modResults.contents.includes(marker))
      mod.modResults.contents += nativeLibraries;
    return mod;
  });
};
