# DuoCam — correção nativa TCP e sessão V100

Código atualizado em 5 de novembro de 2026. O ZIP não contém APK. A imagem da câmera confirmou getmediainfo com rtsp://192.168.169.1 e transporte tcp e confirmou enterrecorder com sucesso, mas o DuoCam antigo continuou sem vídeo.

## Por que existe uma nova correção

Encontramos um defeito na biblioteca aberta VLC 1.0.98: o código Android descartava o último elemento de initOptions/mediaOptions. A opção --rtsp-tcp era justamente o último elemento passado pelo DuoCam. O patch incluído corrige ambos os limites; a aplicação efetiva à dependência instalada foi verificada. Não foi provado que esse seja o único problema de compatibilidade da câmera.

O cadastro também oferece Abertura de sessão, opcional e inicialmente desativada. Em modo descoberta, quando ativada, obtém URL válida e envia /app/enterrecorder antes de montar VLC, sem transmitir a senha Wi-Fi. Não é somente leitura e cancelar não desfaz sessão já aceita. Nenhum exitrecorder ou comando de senha, rede, cartão ou gravação é enviado automaticamente.

## Aplicar a atualização

Esta correção altera Java. É necessário compilar e instalar um novo APK; atualização apenas de JavaScript/Preview/Metro não resolve. O app já instalado permanece com sua biblioteca anterior. Nenhum APK foi gerado nesta etapa.

No Manus, use o fluxo Android do painel após o código atualizado. Fora da plataforma, extraia DuoCam em um computador com Node.js compatível (por exemplo série22 >=22.13), Android Studio/SDK/JDK compatíveis, e execute na pasta:

```sh
npm install --global pnpm@9.12.0
pnpm install --frozen-lockfile
pnpm check
pnpm test
pnpm exec expo prebuild --platform android
```

Mantenha package.json, pnpm-lock.yaml e patches/react-native-vlc-media-player@1.0.98.patch juntos. Não troque para npm/yarn ignorando o patch. O prebuild cria android, mas não gera sozinho APK. Abra android no Android Studio, sincronize Gradle e gere um APK release assinado se quiser instalar sem Metro. Preserve o identificador space.manus.duocam.t117139310659128 e a assinatura para atualizar a instalação existente; não remova dados/mídia sem exportar se a assinatura for diferente. Chaves, senhas de assinatura e SDK não estão no ZIP.

## Testar depois do novo APK

Conecte o telefone/tablet ao Wi-Fi da câmera e feche a visualização de outros apps. No cadastro DuoCam, informe o SSID real, selecione Descobrir V100, confira gateway192.168.169.1 (ou Roteador real do Wi-Fi), ative Abertura de sessão e escolha TCP (ou Automático, que segue tcp recebido). Salve e toque em Conectar. Não é necessário abrir enterrecorder no navegador nesse modo.

A URL real fornecida no teste é rtsp://192.168.169.1, sem :5000. O campo port5000 é separado como socket de mensagens no parser do app original. Modo manual continua sem abertura automática; usar apenas a URL manual não executa essa opção. Duas câmeras são cadastradas, uma por vez; a terceira relatada não foi incorporada como terceiro cadastro.

Se falhar no build novo, envie a mensagem de erro e a tela de configuração, ocultando senha/token. Uma aceitação de sessão não significa vídeo decodificado. Não recomendamos outras portas aleatórias, reset ou desativação das proteções globais do aparelho.

## Verificações

TypeScript aprovado e 158 testes aprovados, 1 do starter ignorado. Foram verificadas opções finais, patch registrado/sem ANSI, código Java efetivamente corrigido, sessão opcional, respostas de erro e cancelamento. Bundles JavaScript Web/Android e introspecção Expo aprovados, sem compilar o Java. Reprodução no dispositivo continua pendente.

O ZIP exclui segredos, node_modules, caches, assinaturas e APKs/código/bibliotecas proprietários de Veecar/Viidure. Código da biblioteca aberta tem licença própria. Leia ATUALIZACAO-TCP-SESSAO.md dentro do pacote para os detalhes.
