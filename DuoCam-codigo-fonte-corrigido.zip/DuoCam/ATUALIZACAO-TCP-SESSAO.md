# DuoCam — correção nativa TCP e sessão V100

Atualização de código de 5 de novembro de 2026, após as respostas reais enviadas pelo usuário. Não é um APK e ainda não comprova reprodução na câmera.

## Defeito encontrado e corrigido

A biblioteca aberta react-native-vlc-media-player 1.0.98 percorre listas de opções Android com `i < options.size() - 1`, descartando o último elemento. O DuoCam passa `--network-caching=500` e `--rtsp-tcp`: a última flag de TCP não era enviada ao LibVLC. O mesmo defeito afeta mediaOptions e a flag UDP quando usada no último elemento. Isso é um defeito concreto do repasse de opções, mas não prova que seja a única causa da falha física.

O patch `patches/react-native-vlc-media-player@1.0.98.patch` corrige ambos os limites para `i < options.size()`. Foi registrado em package.json/pnpm-lock.yaml e aplicado à dependência instalada com `pnpm install --frozen-lockfile`; ambos os laços efetivos foram conferidos. Não há flag falsa ou duplicada para contornar o problema. O primeiro diff gerado continha escapes de cor que impediam aplicar a alteração; o arquivo final é um patch plain-text sem ANSI, com hash recalculado e aplicação confirmada.

Fonte aberta também consultada: https://raw.githubusercontent.com/razorRun/react-native-vlc-media-player/master/android/src/main/java/com/yuanzhou/vlc/vlcplayer/ReactVlcPlayerView.java . O master consultado contém o mesmo defeito, mas o patch foi feito sobre a versão instalada 1.0.98, não substituindo toda a biblioteca pelo master. O wrapper JavaScript instalado já reconhece RTSP como rede; não foi necessário acrescentar uma marcação de rede redundante.

## O que a câmera confirmou

Na foto de /app/getmediainfo, a resposta foi result=0 com rtsp=rtsp://192.168.169.1, transport=tcp e port=5000. Não usar esse port como porta de vídeo: o parser dos apps enviados o armazena separadamente como socket de mensagens. A URL informada não contém :5000.

A foto de /app/enterrecorder mostrou result=0 e info="enter recorder success". Isso confirma que a câmera aceita a operação de entrada da sessão. O DuoCam continuou SEM VÍDEO no teste manual; essa tela não fornece causa detalhada de RTSP/decoder. Ainda não há prova de RTSP PLAY ou quadros decodificados no telefone/tablet.

## Abertura opcional no DuoCam

No modo Descobrir V100, o cadastro oferece **Abertura de sessão · ATIVADA/DESATIVADA**. Fica desativada por padrão, inclusive em cadastros existentes. O usuário deve ativar explicitamente para o equipamento que aceitou esse comando. Com a opção ligada, o app consulta identificação, obtém uma URL válida e só então envia /app/enterrecorder antes de montar o VLC. É abertura de modo/sessão, não apenas leitura; nenhuma senha Wi-Fi é enviada como login.

A resposta de sessão exige result inteiro 0 e info string não vazia, diferentemente do info objeto das consultas de identificação/mídia. Falhas, prazo e cancelamento impedem iniciar player por resposta tardia. Um comando já aceito na câmera não é desfeito pelo cancelamento HTTP. Não enviamos exitrecorder automaticamente nem alteramos relógio, senha, rede, resolução, gravação no cartão ou formatação. O modo manual continua sem consultas/abertura automáticas.

## Aplicar a atualização

Esta correção altera Java da biblioteca: atualização só de interface/Metro/JavaScript não basta. Compilar e instalar um novo APK com o patch incluído. No painel Manus, usar o fluxo Android após o código atualizado. Fora do Manus, manter pnpm@9.12.0 e instalar com o lockfile/patch antes do prebuild e da compilação; não usar npm/yarn ignorando o patch. O build nativo não foi executado nesta sessão.

Depois da nova instalação, conectar ao Wi-Fi real da câmera, fechar a visualização de outros apps, editar o cadastro, escolher Descobrir V100, gateway 192.168.169.1 (ou o Roteador real), ativar Abertura de sessão e selecionar TCP (ou Automático, que segue tcp recebido). Salvar e tocar em Conectar. Não é necessário abrir o navegador para enterrecorder nesse modo. Cadastros e URLs anteriores permanecem salvos.

## Evidência disponível

TypeScript e 158 testes aprovados, com 1 teste do starter ignorado. Há 18 novos testes da sessão opcional e 5 verificações estruturais do patch, além dos testes anteriores. Verificamos o fonte Java instalado e o registro do patch no lockfile; não compilamos nem executamos Java/LibVLC no aparelho. Fixtures são sintéticas e a reprodução real continua pendente. Não declarar vídeo funcionando só porque a câmera aceitou enterrecorder.
