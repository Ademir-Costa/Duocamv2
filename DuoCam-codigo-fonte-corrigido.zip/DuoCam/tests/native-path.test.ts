import { describe, expect, it } from "vitest";
import { nativeFileUri } from "../lib/cameras/native-path";
describe("caminho de arquivo do player VLC", () => {
  it("converte caminhos absolutos retornados pelo VLC em file URI", () =>
    expect(nativeFileUri("/data/user/0/duocam/files/photo.jpg")).toBe(
      "file:///data/user/0/duocam/files/photo.jpg",
    ));
  it("preserva file URI e content URI", () => {
    expect(nativeFileUri("file:///data/video.mp4")).toBe(
      "file:///data/video.mp4",
    );
    expect(nativeFileUri("content://provider/media/1")).toBe(
      "content://provider/media/1",
    );
  });
  it("rejeita endereços remotos ou paths relativos", () => {
    expect(() => nativeFileUri("https://host/video")).toThrow();
    expect(() => nativeFileUri("video.mp4")).toThrow();
  });
});
