import { describe, expect, it } from "vitest";
import {
  PlaybackMonitor,
  VIDEO_CONNECT_TIMEOUT_MS,
  VIDEO_STALL_TIMEOUT_MS,
} from "../lib/cameras/playback-monitor";
const video = { width: 1920, height: 1080 };

describe("evidência de reprodução de vídeo", () => {
  it("inicia aguardando e falha sem eventos em 25 segundos", () => {
    const monitor = new PlaybackMonitor(100);
    monitor.tick(100 + VIDEO_CONNECT_TIMEOUT_MS - 1);
    expect(monitor.snapshot().status).toBe("connecting");
    monitor.tick(100 + VIDEO_CONNECT_TIMEOUT_MS);
    expect(monitor.snapshot().status).toBe("error");
  });
  it("progresso de áudio ou sem faixa de vídeo não confirma vídeo", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteProgress(100, 1000);
    monitor.noteProgress(200, 2000);
    expect(monitor.snapshot().status).toBe("connecting");
    monitor.tick(VIDEO_CONNECT_TIMEOUT_MS);
    expect(monitor.snapshot().status).toBe("error");
  });
  it.each([
    undefined,
    null,
    {},
    { width: 0, height: 1080 },
    { width: 1920, height: -1 },
    { width: NaN, height: 1080 },
    { width: Infinity, height: 1080 },
    { width: "1920", height: 1080 },
  ])("rejeita dimensões inválidas: %j", (size) => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(size, 100);
    monitor.noteProgress(1, 1000);
    expect(monitor.snapshot().status).toBe("connecting");
  });
  it.each([undefined, null, NaN, Infinity, -1, "10", 0])(
    "rejeita progresso inválido ou zero: %j",
    (time) => {
      const monitor = new PlaybackMonitor(0);
      monitor.noteVideo(video, 100);
      monitor.noteProgress(time, 1000);
      expect(monitor.snapshot().status).toBe("connecting");
    },
  );
  it("somente metadados de vídeo não cancelam o prazo", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(video, 10);
    monitor.noteVideo(video, 24_000);
    monitor.tick(VIDEO_CONNECT_TIMEOUT_MS);
    expect(monitor.snapshot().status).toBe("error");
  });
  it("identifica reprodução com faixa válida e tempo avançando", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 1000);
    expect(monitor.snapshot().status).toBe("playing");
  });
  it("permite que metadados cheguem depois de progresso recente", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteProgress(1000, 1000);
    monitor.noteVideo(video, 2000);
    expect(monitor.snapshot().status).toBe("playing");
  });
  it("não considera progresso antigo como prova de reprodução atual", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteProgress(1000, 1000);
    monitor.noteVideo(video, 1000 + VIDEO_STALL_TIMEOUT_MS);
    expect(monitor.snapshot().status).toBe("connecting");
  });
  it("progresso repetido ou retrocedendo não renova o watchdog", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 1000);
    monitor.noteProgress(1000, 10_000);
    monitor.noteProgress(500, 12_000);
    monitor.tick(1000 + VIDEO_STALL_TIMEOUT_MS);
    expect(monitor.snapshot().status).toBe("error");
  });
  it("progresso válido renovado mantém a sessão", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 1000);
    monitor.noteProgress(2000, 14_000);
    monitor.tick(20_000);
    expect(monitor.snapshot().status).toBe("playing");
  });
  it("buffering repetido não esconde estagnação", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 1000);
    monitor.buffering();
    monitor.buffering();
    monitor.tick(1000 + VIDEO_STALL_TIMEOUT_MS);
    expect(monitor.snapshot().status).toBe("error");
  });
  it("buffering não estende o prazo inicial", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.buffering();
    monitor.tick(VIDEO_CONNECT_TIMEOUT_MS);
    expect(monitor.snapshot().status).toBe("error");
  });
  it("callbacks tardios não revertem erro nem escondem o diagnóstico", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.fail("Erro original");
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 1000);
    monitor.buffering();
    monitor.stop();
    monitor.fail("Outro erro");
    expect(monitor.snapshot()).toEqual({
      status: "error",
      detail: "Erro original",
    });
  });
  it("não recupera a mesma tentativa após timeout", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.tick(VIDEO_CONNECT_TIMEOUT_MS);
    monitor.noteVideo(video, 26_000);
    monitor.noteProgress(1000, 26_001);
    expect(monitor.snapshot().status).toBe("error");
    const retry = new PlaybackMonitor(27_000);
    retry.noteVideo(video, 27_001);
    retry.noteProgress(1000, 28_000);
    expect(retry.snapshot().status).toBe("playing");
  });
  it("progresso recebido após o prazo não cancela timeout antes do tick", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 25_001);
    expect(monitor.snapshot().status).toBe("error");
  });
  it("metadados atrasados também respeitam o prazo inicial", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteProgress(1000, 24_000);
    monitor.noteVideo(video, 25_001);
    expect(monitor.snapshot().status).toBe("error");
  });
  it("progresso após estagnação não ressuscita a mesma tentativa", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 1000);
    monitor.noteProgress(2000, 16_001);
    expect(monitor.snapshot().status).toBe("error");
  });
  it("callbacks tardios não restauram uma sessão parada", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.stop();
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 1000);
    monitor.tick(30_000);
    expect(monitor.snapshot().status).toBe("idle");
  });
  it("remover a faixa de vídeo impede renovação por áudio", () => {
    const monitor = new PlaybackMonitor(0);
    monitor.noteVideo(video, 100);
    monitor.noteProgress(1000, 1000);
    monitor.noteVideo(undefined, 2000);
    monitor.noteProgress(2000, 10_000);
    monitor.tick(16_000);
    expect(monitor.snapshot().status).toBe("error");
  });
});
