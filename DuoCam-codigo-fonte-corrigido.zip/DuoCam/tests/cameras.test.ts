import { describe, expect, it } from "vitest";
import {
  DEFAULT_CAMERAS,
  EMPTY_SESSION,
  restoreCameras,
  selectSession,
  updateSession,
  validateCamera,
  validateStreamUrl,
} from "../lib/cameras/model";
describe("duas câmeras com uma sessão", () => {
  it("seleciona uma nova câmera substituindo a anterior", () => {
    const one = updateSession(selectSession(EMPTY_SESSION, "1"), 1, "playing");
    const two = selectSession(one, "2");
    expect(two).toEqual({ cameraId: "2", status: "connecting", generation: 2 });
  });
  it("ignora callbacks de uma câmera anterior", () => {
    const one = selectSession(EMPTY_SESSION, "1");
    const two = selectSession(one, "2");
    expect(updateSession(two, one.generation, "playing")).toEqual(two);
  });
  it("parar invalida os callbacks pendentes", () => {
    const one = selectSession(EMPTY_SESSION, "1");
    const stopped = selectSession(one, null);
    expect(
      updateSession(stopped, one.generation, "playing").cameraId,
    ).toBeNull();
  });
  it("retém apenas os dois IDs e não aceita dados corrompidos", () => {
    expect(restoreCameras([{ id: "3", name: "X" }])).toEqual(DEFAULT_CAMERAS);
    expect(restoreCameras(null)).toHaveLength(2);
  });
});
describe("endereços e cadastro", () => {
  it("aceita URLs de stream configuráveis", () => {
    expect(validateStreamUrl("rtsp://192.168.1.1/live")).toBeNull();
    expect(validateStreamUrl("https://camera.local/video")).toBeNull();
  });
  it("não aceita scripts, caminhos, credenciais ou endereços vazios", () => {
    for (const url of [
      "",
      "javascript:alert(1)",
      "192.168.1.1/live",
      "rtsp://user:password@192.168.1.1/live",
      "file:///tmp/video",
    ])
      expect(validateStreamUrl(url)).not.toBeNull();
  });
  it("permite salvar sem inventar uma URL para VT-100", () =>
    expect(validateCamera(DEFAULT_CAMERAS[0])).toBeNull());
  it("rejeita nome e SSID vazios", () => {
    expect(validateCamera({ ...DEFAULT_CAMERAS[0], name: "" })).not.toBeNull();
    expect(validateCamera({ ...DEFAULT_CAMERAS[0], ssid: "" })).not.toBeNull();
  });
});
