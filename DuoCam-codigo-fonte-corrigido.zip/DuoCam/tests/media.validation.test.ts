import { describe, expect, it } from "vitest";

import {
  fileNameFromUrl,
  isHttpUrl,
  mediaKindFromName,
  safeFileName,
} from "../lib/media/utils";

describe("media URL validation", () => {
  it.each([
    "https://camera.local/DCIM/clip.mp4",
    "http://192.168.1.1:8080/media/frame.jpg",
  ])("accepts a direct HTTP(S) media URL: %s", (url) => {
    expect(isHttpUrl(url)).toBe(true);
  });

  it.each([
    "",
    "rtsp://192.168.1.1/live",
    "file:///data/user/0/app/clip.mp4",
    "ftp://camera.local/clip.mp4",
    "not a url",
  ])("rejects a non-HTTP(S) download source: %s", (url) => {
    expect(isHttpUrl(url)).toBe(false);
  });
});

describe("media file names", () => {
  it("removes path traversal characters and adds a safe fallback extension", () => {
    expect(safeFileName(" ../../registro final ", "video")).toBe(
      "registro final.mp4",
    );
    expect(safeFileName("imagem", "photo")).toBe("imagem.jpg");
  });

  it("uses a safe filename decoded from a direct URL", () => {
    expect(
      fileNameFromUrl("https://camera.local/files/foto%20frontal.JPG?token=x"),
    ).toBe("foto frontal.JPG");
  });

  it("classifies known photo names and treats the remaining capture formats as video", () => {
    expect(mediaKindFromName("quadro.webp")).toBe("photo");
    expect(mediaKindFromName("viagem.mp4")).toBe("video");
    expect(mediaKindFromName("arquivo-sem-extensao")).toBe("video");
  });
});
