import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { vlcOptions } from "../lib/cameras/discovery";
const require = createRequire(import.meta.url);
const packageRoot = dirname(
  require.resolve("react-native-vlc-media-player/package.json"),
);
const java = readFileSync(
  resolve(
    packageRoot,
    "android/src/main/java/com/yuanzhou/vlc/vlcplayer/ReactVlcPlayerView.java",
  ),
  "utf8",
);
const patch = readFileSync(
  resolve(process.cwd(), "patches/react-native-vlc-media-player@1.0.98.patch"),
  "utf8",
);
describe("patch VLC — verificação estrutural, não execução Java/Android", () => {
  it("os dois laços instalados percorrem toda a lista", () => {
    expect(
      java.match(/for \(int i = 0; i < options\.size\(\); i\+\+\)/g),
    ).toHaveLength(2);
    expect(java).not.toContain("options.size() - 1");
    expect(java).toMatch(
      /if \(initOptions != null\)[\s\S]*?i < options\.size\(\); i\+\+[\s\S]*?cOptions\.add\(option\)/,
    );
    expect(java).toMatch(
      /if \(mediaOptions != null\)[\s\S]*?i < options\.size\(\); i\+\+[\s\S]*?m\.addOption\(option\)/,
    );
  });
  it("patch versionado não contém cores ANSI e corrige os dois limites", () => {
    expect(patch).not.toContain("\x1b");
    expect(patch.match(/^\+.*i < options\.size\(\); i\+\+/gm)).toHaveLength(2);
  });
  it("package e lockfile registram o patch para a instalação limpa", () => {
    const pkg = JSON.parse(
      readFileSync(resolve(process.cwd(), "package.json"), "utf8"),
    );
    expect(
      pkg.pnpm.patchedDependencies["react-native-vlc-media-player@1.0.98"],
    ).toBe("patches/react-native-vlc-media-player@1.0.98.patch");
    const lock = readFileSync(resolve(process.cwd(), "pnpm-lock.yaml"), "utf8");
    expect(lock).toContain("patchedDependencies:");
    expect(lock).toContain(
      "path: patches/react-native-vlc-media-player@1.0.98.patch",
    );
    expect(lock).toMatch(
      /react-native-vlc-media-player:[\s\S]*?version: 1\.0\.98\(patch_hash=/,
    );
  });
  it.each(["tcp", "udp"] as const)(
    "flag final %s não precisa de preenchimento artificial",
    (transport) => {
      const list = vlcOptions(transport);
      expect(list).toHaveLength(2);
      expect(list[1]).toBe(
        transport === "tcp" ? "--rtsp-tcp" : "--no-rtsp-tcp",
      );
      const copied: string[] = [];
      for (let i = 0; i < list.length; i++) copied.push(list[i]);
      expect(copied).toEqual(list);
      expect(list.slice(0, -1)).not.toContain(list[1]);
    },
  );
});
