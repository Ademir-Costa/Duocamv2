import { afterEach, describe, expect, it, vi } from "vitest";
import {
  discoverConnection,
  parseSessionResponse,
} from "../lib/cameras/connection";
import { DEFAULT_CAMERAS, restoreCameras } from "../lib/cameras/model";
const gateway = "192.168.169.1";
const device = { result: 0, info: { uuid: "fixture", curcamid: 0 } };
const media = {
  result: 0,
  info: { rtsp: `rtsp://${gateway}`, transport: "tcp", port: 5000 },
};
const accepted = { result: 0, info: "enter recorder success" };
function response(value: unknown) {
  return { status: 200, text: async () => JSON.stringify(value) } as Response;
}
function makeFetcher() {
  return vi
    .fn()
    .mockResolvedValueOnce(response(device))
    .mockResolvedValueOnce(response(media))
    .mockResolvedValueOnce(response(accepted));
}
afterEach(() => vi.useRealTimers());
describe("sessão opcional", () => {
  it("aceita result0/info string diferente de mídia info objeto", () =>
    expect(() => parseSessionResponse(accepted)).not.toThrow());
  it.each([
    {},
    [],
    null,
    { result: "0", info: "success" },
    { result: 0, info: {} },
    { result: 0, info: "" },
  ])("rejeita resposta inválida %j", (value) =>
    expect(() => parseSessionResponse(value)).toThrow(),
  );
  it("recusa result98 e não mostra informação bruta", () => {
    try {
      parseSessionResponse({ result: 98, info: "secret" });
      throw new Error("expected failure");
    } catch (e) {
      expect(e).toMatchObject({ code: "session-result-98" });
      expect((e as Error).message).not.toContain("secret");
    }
  });
  it.each([undefined, false])(
    "não envia enterrecorder sem ativação explícita (%j)",
    async (prepareSession) => {
      const fetcher = makeFetcher();
      const stream = await discoverConnection({
        gateway,
        fetcher,
        prepareSession,
      });
      expect(stream).toEqual({
        uri: `rtsp://${gateway}`,
        transport: "tcp",
        channel: 0,
      });
      expect(fetcher).toHaveBeenCalledTimes(2);
    },
  );
  it("obtém URL válida e só então abre sessão com GET sem senha", async () => {
    const fetcher = makeFetcher();
    const steps: string[] = [];
    const stream = await discoverConnection({
      gateway,
      fetcher,
      prepareSession: true,
      onStage: (s) => steps.push(s),
    });
    expect(stream.uri).toBe(`rtsp://${gateway}`);
    expect(steps).toEqual(["device", "media", "session"]);
    expect(fetcher.mock.calls.map(([url]) => url)).toEqual([
      `http://${gateway}/app/getdeviceattr`,
      `http://${gateway}/app/getmediainfo`,
      `http://${gateway}/app/enterrecorder`,
    ]);
    const init = fetcher.mock.calls[2][1];
    expect(init.method).toBe("GET");
    expect(init.body).toBeUndefined();
    expect(init.credentials).toBe("omit");
    expect(init.headers).toEqual({ Accept: "application/json" });
  });
  it("não retorna URL se a câmera recusar sessão", async () => {
    const fetcher = makeFetcher().mockResolvedValueOnce(response(accepted));
    fetcher
      .mockReset()
      .mockResolvedValueOnce(response(device))
      .mockResolvedValueOnce(response(media))
      .mockResolvedValueOnce(response({ result: 98, info: "unavailable" }));
    await expect(
      discoverConnection({ gateway, fetcher, prepareSession: true }),
    ).rejects.toMatchObject({ code: "session-result-98" });
    expect(fetcher).toHaveBeenCalledTimes(3);
  });
  it("não abre sessão após URL inválida", async () => {
    const fetcher = vi
      .fn()
      .mockResolvedValueOnce(response(device))
      .mockResolvedValueOnce(
        response({
          result: 0,
          info: { rtsp: "http://external.example/video" },
        }),
      );
    await expect(
      discoverConnection({ gateway, fetcher, prepareSession: true }),
    ).rejects.toMatchObject({ code: "media-host" });
    expect(fetcher).toHaveBeenCalledTimes(2);
  });
  it("cancelar antes da abertura não envia a operação", async () => {
    const fetcher = makeFetcher();
    const controller = new AbortController();
    await expect(
      discoverConnection({
        gateway,
        fetcher,
        prepareSession: true,
        signal: controller.signal,
        onStage: (s) => {
          if (s === "session") controller.abort();
        },
      }),
    ).rejects.toMatchObject({ code: "cancelled" });
    expect(fetcher).toHaveBeenCalledTimes(2);
  });
  it("cancelar durante abertura ignora sucesso tardio e não envia exitrecorder", async () => {
    let finish!: (r: Response) => void;
    const fetcher = vi
      .fn()
      .mockResolvedValueOnce(response(device))
      .mockResolvedValueOnce(response(media))
      .mockImplementationOnce(
        () =>
          new Promise<Response>((resolve) => {
            finish = resolve;
          }),
      );
    const controller = new AbortController();
    const pending = discoverConnection({
      gateway,
      fetcher,
      prepareSession: true,
      signal: controller.signal,
    });
    await vi.waitFor(() => expect(fetcher).toHaveBeenCalledTimes(3));
    const assertion = expect(pending).rejects.toMatchObject({
      code: "cancelled",
    });
    controller.abort();
    finish(response(accepted));
    await assertion;
    expect(fetcher).toHaveBeenCalledTimes(3);
    expect(
      fetcher.mock.calls.every(
        ([url]) => !String(url).includes("exitrecorder"),
      ),
    ).toBe(true);
  });
  it("prazo da sessão inclui corpo e não retorna stream ao expirar", async () => {
    vi.useFakeTimers();
    const fetcher = vi
      .fn()
      .mockResolvedValueOnce(response(device))
      .mockResolvedValueOnce(response(media))
      .mockImplementationOnce(() => new Promise<Response>(() => {}));
    const assertion = expect(
      discoverConnection({
        gateway,
        fetcher,
        prepareSession: true,
        timeoutMs: 100,
      }),
    ).rejects.toMatchObject({ code: "session-timeout" });
    await vi.advanceTimersByTimeAsync(100);
    await assertion;
    expect(fetcher).toHaveBeenCalledTimes(3);
  });
  it("dados novos e legados não ativam preparação silenciosamente", () => {
    expect(DEFAULT_CAMERAS.every((c) => c.prepareSession === false)).toBe(true);
    const old = {
      id: "1",
      name: "Frontal",
      ssid: "rede",
      url: `rtsp://${gateway}`,
    };
    expect(restoreCameras([old])[0].prepareSession).toBe(false);
  });
  it("a opção explícita é restaurada sem mudar URL ou modo", () => {
    const enabled = { ...DEFAULT_CAMERAS[0], prepareSession: true };
    expect(restoreCameras([enabled])[0]).toEqual(enabled);
  });
});
