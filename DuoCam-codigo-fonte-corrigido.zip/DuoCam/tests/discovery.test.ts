import { afterEach, describe, expect, it, vi } from "vitest";
import {
  discoverStream,
  parseDevice,
  parseEnvelope,
  parseMedia,
  streamSummary,
  vlcOptions,
} from "../lib/cameras/discovery";
import {
  cameraMode,
  cameraTransport,
  DEFAULT_CAMERAS,
  restoreCameras,
  validateConnection,
  validateGateway,
} from "../lib/cameras/model";
const gateway = "192.168.169.1";
const device = { result: 0, info: { uuid: "synthetic-device", curcamid: 0 } };
const media = {
  result: 0,
  info: {
    rtsp: `rtsp://${gateway}:554/live/preview`,
    transport: "UDP",
    port: 5000,
  },
};
function reply(value: unknown, status = 200) {
  return {
    status,
    url: `http://${gateway}/app/getdeviceattr`,
    text: async () => JSON.stringify(value),
  } as Response;
}
afterEach(() => vi.useRealTimers());
describe("descoberta readonly", () => {
  it("consulta identificação e mídia, não altera câmera nem envia senha", async () => {
    const fetcher = vi
      .fn()
      .mockResolvedValueOnce(reply(device))
      .mockResolvedValueOnce(reply(media));
    const stages: string[] = [];
    const stream = await discoverStream({
      gateway,
      fetcher,
      onStage: (s) => stages.push(s),
    });
    expect(stream).toEqual({
      uri: media.info.rtsp,
      transport: "udp",
      channel: 0,
    });
    expect(fetcher.mock.calls.map((c) => c[0])).toEqual([
      `http://${gateway}/app/getdeviceattr`,
      `http://${gateway}/app/getmediainfo`,
    ]);
    expect(stages).toEqual(["device", "media"]);
    for (const [, init] of fetcher.mock.calls) {
      expect(init.method).toBe("GET");
      expect(init.body).toBeUndefined();
      expect(init.credentials).toBe("omit");
      expect(init.headers).toEqual({ Accept: "application/json" });
    }
  });
  it("não usa info.port=5000 como porta de vídeo", () => {
    expect(parseMedia(media, gateway, 0).uri).toBe(media.info.rtsp);
  });
  it("usa o canal da câmera e não o ID do cadastro DuoCam", async () => {
    const fetcher = vi
      .fn()
      .mockResolvedValueOnce(
        reply({ ...device, info: { ...device.info, curcamid: 1 } }),
      )
      .mockResolvedValueOnce(
        reply({
          result: 0,
          info: {
            rtsps: [`rtsp://${gateway}/first`, `rtsp://${gateway}/second`],
            transport: "tcp",
          },
        }),
      );
    expect((await discoverStream({ gateway, fetcher })).uri).toBe(
      `rtsp://${gateway}/second`,
    );
  });
  it("sem URL não inventa fallback RTSP", () => {
    expect(() =>
      parseMedia({ result: 0, info: { port: 5000 } }, gateway, 0),
    ).toThrow("não forneceu");
  });
  it("não ignora um canal fora da lista", () => {
    expect(() =>
      parseMedia({ result: 0, info: { rtsps: [] } }, gateway, 0),
    ).toThrow("canal");
  });
  it.each([
    {},
    [],
    { result: "0", info: {} },
    { result: 0, info: null },
    { result: 0, info: [] },
  ])("rejeita envelope inválido %j", (value) => {
    expect(() => parseEnvelope(value, "media")).toThrow();
  });
  it("não mostra mensagem bruta que pode incluir token", () => {
    expect(() =>
      parseEnvelope({ result: 5, info: "secret-token" }, "media"),
    ).toThrow("código 5");
    try {
      parseEnvelope({ result: 5, info: "secret-token" }, "media");
    } catch (e) {
      expect((e as Error).message).not.toContain("secret-token");
    }
  });
  it("precisa de identificação de família", () =>
    expect(() => parseDevice({ result: 0, info: {} })).toThrow(
      "não identificou",
    ));
  it.each([-1, "1", 1.5])("rejeita canal inválido %j", (curcamid) =>
    expect(() =>
      parseDevice({ result: 0, info: { uuid: "fixture", curcamid } }),
    ).toThrow("índice"),
  );
  it.each([
    `rtsp://192.168.169.2/live`,
    "https://external.example/video",
    `rtsp://admin:12345678@${gateway}/live`,
    "file:///video",
    `rtsp://${gateway}/live#token`,
  ])("rejeita URL não segura %s", (rtsp) => {
    expect(() =>
      parseMedia({ result: 0, info: { rtsp } }, gateway, 0),
    ).toThrow();
  });
  it("não envia resposta/caminho/query ao diagnóstico", () => {
    const stream = parseMedia(
      {
        result: 0,
        info: {
          rtsp: `rtsp://${gateway}:554/private-id?token=secret`,
          transport: "tcp",
        },
      },
      gateway,
      0,
    );
    expect(streamSummary(stream)).toBe(`rtsp://${gateway}:554 · canal 1 · TCP`);
    expect(streamSummary(stream)).not.toMatch(/secret|token|private-id/);
  });
  it("não trata transporte desconhecido como TCP obrigatório", () => {
    expect(
      parseMedia(
        { result: 0, info: { rtsp: media.info.rtsp, transport: "custom" } },
        gateway,
        0,
      ).transport,
    ).toBe("auto");
    expect(vlcOptions("auto")).toEqual(["--network-caching=500"]);
    expect(vlcOptions("udp")).toContain("--no-rtsp-tcp");
    expect(vlcOptions("tcp")).toContain("--rtsp-tcp");
  });
  it.each([401, 403, 404, 500])(
    "informa falha HTTP %s sem tentar mídia",
    async (status) => {
      const fetcher = vi.fn().mockResolvedValue(reply({}, status));
      await expect(discoverStream({ gateway, fetcher })).rejects.toMatchObject({
        code: `device-http-${status}`,
      });
      expect(fetcher).toHaveBeenCalledTimes(1);
    },
  );
  it("não tenta mídia quando a identificação é incompatível", async () => {
    const fetcher = vi.fn().mockResolvedValue(reply({ result: 0, info: {} }));
    await expect(discoverStream({ gateway, fetcher })).rejects.toMatchObject({
      code: "device-identity",
    });
    expect(fetcher).toHaveBeenCalledTimes(1);
  });
  it("trata erro de rede sem expor URL/segredo do erro original", async () => {
    const fetcher = vi
      .fn()
      .mockRejectedValue(new Error("secret-network-error"));
    await expect(discoverStream({ gateway, fetcher })).rejects.toMatchObject({
      code: "device-network",
    });
  });
  it("rejeita JSON inválido", async () => {
    const fetcher = vi.fn().mockResolvedValue({
      status: 200,
      text: async () => "<html>login</html>",
    });
    await expect(discoverStream({ gateway, fetcher })).rejects.toMatchObject({
      code: "device-json",
    });
  });
  it("limita o corpo de resposta", async () => {
    const fetcher = vi
      .fn()
      .mockResolvedValue({ status: 200, text: async () => "a".repeat(65537) });
    await expect(discoverStream({ gateway, fetcher })).rejects.toMatchObject({
      code: "device-size",
    });
  });
  it("rejeita redirecionamento para outro host", async () => {
    const fetcher = vi.fn().mockResolvedValue({
      ...reply(device),
      url: "http://external.example/login",
    });
    await expect(discoverStream({ gateway, fetcher })).rejects.toMatchObject({
      code: "device-redirect",
    });
  });
  it("timeout encerra consulta mesmo quando fetch ignora AbortSignal", async () => {
    vi.useFakeTimers();
    const fetcher = vi.fn(
      (_input: RequestInfo | URL, _init?: RequestInit) =>
        new Promise<Response>(() => {}),
    );
    const pending = discoverStream({ gateway, fetcher, timeoutMs: 100 });
    const assertion = expect(pending).rejects.toMatchObject({
      code: "device-timeout",
    });
    await vi.advanceTimersByTimeAsync(100);
    await assertion;
    expect(fetcher.mock.calls[0][1]?.signal?.aborted).toBe(true);
  });
  it("timeout inclui leitura do corpo", async () => {
    vi.useFakeTimers();
    const fetcher = vi
      .fn()
      .mockResolvedValue({ status: 200, text: () => new Promise(() => {}) });
    const assertion = expect(
      discoverStream({ gateway, fetcher, timeoutMs: 100 }),
    ).rejects.toMatchObject({ code: "device-timeout" });
    await vi.advanceTimersByTimeAsync(100);
    await assertion;
  });
  it("cancelamento impede mídia mesmo se a resposta chegar depois", async () => {
    let deliver!: (r: Response) => void;
    const fetcher = vi.fn(
      () =>
        new Promise<Response>((resolve) => {
          deliver = resolve;
        }),
    );
    const controller = new AbortController();
    const pending = discoverStream({
      gateway,
      fetcher,
      signal: controller.signal,
    });
    const assertion = expect(pending).rejects.toMatchObject({
      code: "cancelled",
    });
    controller.abort();
    deliver(reply(device));
    await assertion;
    expect(fetcher).toHaveBeenCalledTimes(1);
  });
  it("cancelamento durante mídia impede entrega do stream", async () => {
    const controller = new AbortController();
    const fetcher = vi
      .fn()
      .mockResolvedValueOnce(reply(device))
      .mockImplementationOnce(() => new Promise<Response>(() => {}));
    const pending = discoverStream({
      gateway,
      fetcher,
      signal: controller.signal,
      onStage: (stage) => {
        if (stage === "media") setTimeout(() => controller.abort(), 0);
      },
    });
    await expect(pending).rejects.toMatchObject({ code: "cancelled" });
    expect(fetcher).toHaveBeenCalledTimes(2);
  });
  it("não faz chamada se já cancelado", async () => {
    const controller = new AbortController();
    controller.abort();
    const fetcher = vi.fn();
    await expect(
      discoverStream({ gateway, fetcher, signal: controller.signal }),
    ).rejects.toMatchObject({ code: "cancelled" });
    expect(fetcher).not.toHaveBeenCalled();
  });
});
describe("cadastro e gateway", () => {
  it.each(["192.168.169.1", "10.0.0.1", "172.16.0.1", "172.31.0.1"])(
    "aceita endereço privado %s",
    (ip) => expect(validateGateway(ip)).toBeNull(),
  );
  it.each([
    "",
    "8.8.8.8",
    "127.0.0.1",
    "169.254.0.1",
    "172.32.0.1",
    "192.168.169.0",
    "192.168.169.255",
    "192.168.256.1",
    "http://192.168.169.1",
    "192.168.169.1:5000",
    "0192.168.169.1",
    "camera.local",
  ])("rejeita gateway inadequado %s", (ip) =>
    expect(validateGateway(ip)).not.toBeNull(),
  );
  it("preserva cadastro legado, sua URL e TCP no modo manual", () => {
    const legacy = {
      id: "1",
      name: "Minha frontal",
      ssid: "MITSUBISHICARCAM",
      url: `rtsp://${gateway}:5000`,
    };
    const restored = restoreCameras([legacy])[0];
    expect(restored).toMatchObject(legacy);
    expect(cameraMode(restored)).toBe("manual");
    expect(cameraTransport(restored)).toBe("tcp");
  });
  it("novas câmeras permitem descoberta sem URL inventada", () => {
    expect(cameraMode(DEFAULT_CAMERAS[0])).toBe("discovery");
    expect(validateConnection(DEFAULT_CAMERAS[0])).toBeNull();
    expect(DEFAULT_CAMERAS[0].url).toBe("");
  });
  it("salva e restaura os campos de descoberta", () => {
    const camera = {
      ...DEFAULT_CAMERAS[0],
      gateway: "10.0.0.1",
      transport: "udp" as const,
    };
    expect(restoreCameras([camera])[0]).toEqual(camera);
  });
  it("conexão manual sem URL é bloqueada", () =>
    expect(
      validateConnection({ ...DEFAULT_CAMERAS[0], connectionMode: "manual" }),
    ).not.toBeNull());
  it("descoberta não envia requisição a gateway inválido", async () => {
    const fetcher = vi.fn();
    await expect(
      discoverStream({ gateway: "8.8.8.8", fetcher }),
    ).rejects.toMatchObject({ code: "gateway" });
    expect(fetcher).not.toHaveBeenCalled();
  });
});
