const themeColors = {
  primary: { light: "#F4B545", dark: "#F4B545" },
  background: { light: "#10141B", dark: "#10141B" },
  surface: { light: "#1B222D", dark: "#1B222D" },
  foreground: { light: "#F2F4F7", dark: "#F2F4F7" },
  muted: { light: "#8D99AB", dark: "#8D99AB" },
  border: { light: "#303B4B", dark: "#303B4B" },
  success: { light: "#64D6A0", dark: "#64D6A0" },
  warning: { light: "#F4B545", dark: "#F4B545" },
  error: { light: "#F47C7C", dark: "#F47C7C" },
};
module.exports = { themeColors };
