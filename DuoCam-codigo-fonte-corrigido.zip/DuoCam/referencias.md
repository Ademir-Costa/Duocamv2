# Referências para o DuoCam

## Funções verificadas do aplicativo de referência

A descrição pública do Viidure informa suporte a chipsets Novatek e MStar, controle de gravação e fotografia, ajustes da câmera, vídeo ao vivo, reprodução remota, download de fotos e vídeos e edição/compartilhamento. Fonte consultada em 22/10/2026: https://play.google.com/store/apps/details?id=com.vidure.app&hl=en_US

O fabricante também descreve recursos de AR/IA e GPS. Não são equivalentes a simplesmente duplicar o player: envolvem modelos e serviços próprios. Não serão presumidos disponíveis no novo aplicativo sem definição expressa do escopo. Fonte: https://www.viidure.com/

## Reprodução nativa

A biblioteca MIT react-native-vlc-media-player documenta suporte a RTSP, RTP, HLS e HTTP, métodos de snapshot e gravação local. Possui plugin Expo e exige build nativo/de desenvolvimento: não funciona diretamente no Expo Go. A integração com a versão atual de React Native e o hardware precisa ser validada em build e dispositivo. Fonte: https://github.com/razorRun/react-native-vlc-media-player

## Rede e compatibilidade

Dois painéis só recebem imagens simultâneas se ambos os endpoints estiverem alcançáveis pelo celular. Não presumir que duas redes AP independentes serão conectadas ao mesmo tempo. Não declarar descoberta automática, comandos OEM, imagens ao vivo, gravações ou downloads como funcionando sem uma conexão real e respostas verificadas.

O arquivo XAPK anexado será usado apenas para análise de interoperabilidade. Código, bibliotecas comerciais, marca, imagens e assinatura do original não serão reutilizados.
