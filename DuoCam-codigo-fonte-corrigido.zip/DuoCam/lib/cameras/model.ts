export type CameraId = "1" | "2";
export type RtspTransport = "auto" | "tcp" | "udp";
export type Camera = {
  id: CameraId;
  name: string;
  ssid: string;
  url: string;
  connectionMode?: "discovery" | "manual";
  gateway?: string;
  transport?: RtspTransport;
  prepareSession?: boolean;
};
export type SessionStatus = "idle" | "connecting" | "playing" | "error";
export const DEFAULT_GATEWAY = "192.168.169.1";
export const DEFAULT_CAMERAS: Camera[] = [
  {
    id: "1",
    name: "Câmera frontal",
    ssid: "CAMERA_1",
    url: "",
    connectionMode: "discovery",
    gateway: DEFAULT_GATEWAY,
    transport: "auto",
    prepareSession: false,
  },
  {
    id: "2",
    name: "Câmera traseira",
    ssid: "CAMERA_2",
    url: "",
    connectionMode: "discovery",
    gateway: DEFAULT_GATEWAY,
    transport: "auto",
    prepareSession: false,
  },
];
export function cameraMode(camera: Camera) {
  return camera.connectionMode ?? "manual";
}
export function cameraGateway(camera: Camera) {
  return camera.gateway ?? DEFAULT_GATEWAY;
}
export function cameraTransport(camera: Camera): RtspTransport {
  // Keep the legacy player's TCP choice unless the user selects otherwise.
  return camera.transport ?? (cameraMode(camera) === "manual" ? "tcp" : "auto");
}
export function validateGateway(value: string): string | null {
  const text = value.trim();
  if (!/^(0|[1-9]\d{0,2})(\.(0|[1-9]\d{0,2})){3}$/.test(text))
    return "Informe somente o IPv4 privado da câmera, sem protocolo, porta ou caminho.";
  const [a, b, c, d] = text.split(".").map(Number);
  if ([a, b, c, d].some((n) => n > 255) || d === 0 || d === 255)
    return "Informe um IPv4 privado válido do equipamento.";
  if (a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168))
    return null;
  return "A descoberta aceita somente o endereço privado da câmera na rede local.";
}
export function validateStreamUrl(value: string): string | null {
  if (!value.trim())
    return "Informe o endereço de vídeo fornecido pelo fabricante.";
  try {
    const url = new URL(value.trim());
    if (!["rtsp:", "http:", "https:"].includes(url.protocol))
      return "Use um endereço RTSP, HTTP ou HTTPS.";
    if (!url.hostname) return "O endereço precisa identificar a câmera.";
    if (url.username || url.password)
      return "Por segurança, não inclua usuário ou senha no endereço nesta versão.";
    if (url.hash) return "Remova o fragmento (#) do endereço.";
    return null;
  } catch {
    return "Endereço inválido. Inclua o protocolo, por exemplo rtsp://.";
  }
}
export function validateCamera(camera: Camera): string | null {
  if (!camera.name.trim()) return "Dê um nome à câmera.";
  if (camera.name.trim().length > 40)
    return "O nome pode ter até 40 caracteres.";
  if (!camera.ssid.trim()) return "Informe o nome da rede Wi-Fi da câmera.";
  if (camera.ssid.length > 32)
    return "O nome da rede pode ter até 32 caracteres.";
  if (
    camera.connectionMode &&
    !["manual", "discovery"].includes(camera.connectionMode)
  )
    return "Escolha um modo de conexão válido.";
  if (camera.transport && !["auto", "tcp", "udp"].includes(camera.transport))
    return "Escolha Automático, TCP ou UDP.";
  if (
    camera.prepareSession !== undefined &&
    typeof camera.prepareSession !== "boolean"
  )
    return "Escolha se deseja abrir a sessão de visualização.";
  if (cameraMode(camera) === "discovery") {
    const issue = validateGateway(cameraGateway(camera));
    if (issue) return issue;
  }
  return camera.url.trim() ? validateStreamUrl(camera.url) : null;
}
export function validateConnection(camera: Camera): string | null {
  const issue = validateCamera(camera);
  if (issue) return issue;
  return cameraMode(camera) === "discovery"
    ? null
    : validateStreamUrl(camera.url);
}
export function restoreCameras(value: unknown): Camera[] {
  if (!Array.isArray(value)) return DEFAULT_CAMERAS.map((c) => ({ ...c }));
  return DEFAULT_CAMERAS.map((fallback) => {
    const candidate = value.find(
      (c) => c && typeof c === "object" && c.id === fallback.id,
    );
    if (
      !candidate ||
      typeof candidate.name !== "string" ||
      typeof candidate.ssid !== "string" ||
      typeof candidate.url !== "string"
    )
      return { ...fallback };
    const camera: Camera = {
      id: fallback.id,
      name: candidate.name,
      ssid: candidate.ssid,
      url: candidate.url,
      connectionMode:
        candidate.connectionMode === "discovery" ? "discovery" : "manual",
      gateway:
        typeof candidate.gateway === "string" &&
        !validateGateway(candidate.gateway)
          ? candidate.gateway.trim()
          : DEFAULT_GATEWAY,
      transport: ["auto", "tcp", "udp"].includes(candidate.transport)
        ? candidate.transport
        : candidate.connectionMode === "discovery"
          ? "auto"
          : "tcp",
      prepareSession: candidate.prepareSession === true,
    };
    return validateCamera(camera) ? { ...fallback } : camera;
  });
}
export type Session = {
  cameraId: CameraId | null;
  status: SessionStatus;
  generation: number;
};
export const EMPTY_SESSION: Session = {
  cameraId: null,
  status: "idle",
  generation: 0,
};
export function selectSession(
  previous: Session,
  cameraId: CameraId | null,
): Session {
  return {
    cameraId,
    status: cameraId ? "connecting" : "idle",
    generation: previous.generation + 1,
  };
}
export function updateSession(
  previous: Session,
  generation: number,
  status: SessionStatus,
): Session {
  return generation === previous.generation && previous.cameraId
    ? { ...previous, status }
    : previous;
}
