import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  DEFAULT_CAMERAS,
  restoreCameras,
  validateCamera,
  type Camera,
  type CameraId,
} from "./model";
const KEY = "@duocam/cameras/v1";
type CameraContextValue = {
  cameras: Camera[];
  ready: boolean;
  storageError: string | null;
  saveCamera: (camera: Camera) => Promise<void>;
  selected: CameraId;
  setSelected: (id: CameraId) => void;
};
const CameraContext = createContext<CameraContextValue | null>(null);
export function CameraProvider({ children }: { children: ReactNode }) {
  const [cameras, setCameras] = useState(DEFAULT_CAMERAS);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [selected, setSelected] = useState<CameraId>("1");
  const current = useRef(cameras);
  useEffect(() => {
    let alive = true;
    AsyncStorage.getItem(KEY)
      .then((raw) => {
        if (!alive) return;
        const parsed = raw
          ? restoreCameras(JSON.parse(raw))
          : DEFAULT_CAMERAS.map((c) => ({ ...c }));
        current.current = parsed;
        setCameras(parsed);
      })
      .catch(() => {
        if (alive)
          setStorageError("Não foi possível carregar as câmeras salvas.");
      })
      .finally(() => {
        if (alive) setReady(true);
      });
    return () => {
      alive = false;
    };
  }, []);
  async function saveCamera(camera: Camera) {
    if (!ready) throw new Error("Aguarde o carregamento das câmeras salvas.");
    const error = validateCamera(camera);
    if (error) throw new Error(error);
    const cleaned = {
      ...camera,
      name: camera.name.trim(),
      ssid: camera.ssid.trim(),
      url: camera.url.trim(),
      gateway: camera.gateway?.trim(),
    };
    const updated = current.current.map((c) =>
      c.id === camera.id ? cleaned : c,
    );
    await AsyncStorage.setItem(KEY, JSON.stringify(updated));
    current.current = updated;
    setCameras(updated);
    setStorageError(null);
  }
  return (
    <CameraContext.Provider
      value={{
        cameras,
        ready,
        storageError,
        saveCamera,
        selected,
        setSelected,
      }}
    >
      {children}
    </CameraContext.Provider>
  );
}
export function useCameras() {
  const context = useContext(CameraContext);
  if (!context) throw new Error("CameraProvider ausente.");
  return context;
}
