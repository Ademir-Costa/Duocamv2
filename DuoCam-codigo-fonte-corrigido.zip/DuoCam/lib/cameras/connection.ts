import {
  discoverStream,
  DiscoveryError,
  requestJson,
  type DiscoveredStream,
  type DiscoveryStage,
} from "./discovery";
export type ConnectionStage = DiscoveryStage | "session";
export function parseSessionResponse(value: unknown): void {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new DiscoveryError(
      "session-format",
      "A câmera não retornou o formato esperado para abertura da sessão.",
    );
  const result = (value as Record<string, unknown>).result;
  const info = (value as Record<string, unknown>).info;
  if (!Number.isInteger(result))
    throw new DiscoveryError(
      "session-format",
      "A câmera não retornou um resultado válido para abertura da sessão.",
    );
  if (result !== 0)
    throw new DiscoveryError(
      `session-result-${result}`,
      `A câmera recusou a abertura da sessão (código ${result}). O vídeo não foi iniciado. Nenhuma senha Wi-Fi foi enviada como login.`,
    );
  if (typeof info !== "string" || !info.trim())
    throw new DiscoveryError(
      "session-info",
      "A câmera não confirmou a abertura no formato esperado. O vídeo não foi iniciado.",
    );
}
export async function discoverConnection(options: {
  gateway: string;
  prepareSession?: boolean;
  signal?: AbortSignal;
  fetcher?: typeof fetch;
  timeoutMs?: number;
  onStage?: (stage: ConnectionStage) => void;
}): Promise<DiscoveredStream> {
  const stream = await discoverStream(options);
  if (options.signal?.aborted)
    throw new DiscoveryError("cancelled", "Consulta cancelada.");
  if (options.prepareSession === true) {
    // This opens the local viewing session. It is not a read-only metadata query.
    options.onStage?.("session");
    const response = await requestJson(
      options.gateway.trim(),
      "session",
      options.fetcher ?? fetch,
      options.signal,
      options.timeoutMs ?? 8000,
    );
    if (options.signal?.aborted)
      throw new DiscoveryError("cancelled", "Consulta cancelada.");
    parseSessionResponse(response);
  }
  if (options.signal?.aborted)
    throw new DiscoveryError("cancelled", "Consulta cancelada.");
  // Aborting the HTTP request does not roll back an accepted camera-side session.
  // Do not implicitly send exitrecorder: another app might be using that session.
  return stream;
}
