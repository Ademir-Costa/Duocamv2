import {
  validateGateway,
  validateStreamUrl,
  type RtspTransport,
} from "./model";

type JsonObject = Record<string, unknown>;
export type DiscoveredStream = {
  uri: string;
  transport: RtspTransport;
  channel: number;
};
export type DiscoveryStage = "device" | "media";
export class DiscoveryError extends Error {
  constructor(
    public readonly code: string,
    message: string,
  ) {
    super(message);
    this.name = "DiscoveryError";
  }
}
function object(value: unknown): value is JsonObject {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function cancelled() {
  return new DiscoveryError("cancelled", "Consulta cancelada.");
}
export function parseEnvelope(
  value: unknown,
  stage: DiscoveryStage,
): JsonObject {
  if (!object(value) || !Number.isInteger(value.result))
    throw new DiscoveryError(
      `${stage}-format`,
      "Resposta incompatível: a câmera não retornou o formato de descoberta esperado.",
    );
  if (value.result !== 0)
    throw new DiscoveryError(
      `${stage}-result-${value.result}`,
      `A câmera recusou a consulta de ${stage === "device" ? "identificação" : "mídia"} (código ${value.result}). Pode ser necessário outro protocolo ou uma sessão específica; a senha Wi-Fi não é um login de vídeo.`,
    );
  if (!object(value.info))
    throw new DiscoveryError(
      `${stage}-info`,
      "A resposta não contém as informações esperadas da câmera.",
    );
  return value.info;
}
export function parseDevice(value: unknown): { channel: number } {
  const info = parseEnvelope(value, "device");
  if (typeof info.uuid !== "string" || !info.uuid.trim())
    throw new DiscoveryError(
      "device-identity",
      "A câmera respondeu, mas não identificou a família esperada. Não vamos assumir uma URL de vídeo.",
    );
  const channel = info.curcamid === undefined ? 0 : info.curcamid;
  if (!Number.isInteger(channel) || (channel as number) < 0)
    throw new DiscoveryError(
      "device-channel",
      "A câmera informou um índice de vídeo inválido.",
    );
  return { channel: channel as number };
}
export function parseMedia(
  value: unknown,
  gateway: string,
  channel: number,
): DiscoveredStream {
  const info = parseEnvelope(value, "media");
  let uri: unknown;
  if (Array.isArray(info.rtsps)) {
    if (channel >= info.rtsps.length)
      throw new DiscoveryError(
        "media-channel",
        "O canal informado pela câmera não está na lista de transmissões.",
      );
    uri = info.rtsps[channel];
  } else {
    uri = info.rtsp;
  }
  if (typeof uri !== "string" || !uri.trim())
    throw new DiscoveryError(
      "media-missing-url",
      "A câmera respondeu, mas não forneceu uma URL de vídeo. Não usaremos a porta de mensagens como se fosse RTSP.",
    );
  const issue = validateStreamUrl(uri);
  if (issue)
    throw new DiscoveryError(
      "media-url",
      `URL de vídeo não suportada. ${issue}`,
    );
  const parsed = new URL(uri.trim());
  if (parsed.hostname !== gateway)
    throw new DiscoveryError(
      "media-host",
      "A URL retornada aponta para outro endereço. Por segurança, a descoberta só reproduz vídeo do gateway consultado.",
    );
  const reported =
    typeof info.transport === "string"
      ? info.transport.trim().toLowerCase()
      : "";
  const transport: RtspTransport =
    reported === "tcp" || reported === "udp" ? reported : "auto";
  // info.port is a message socket, NOT the media port. Retain the supplied URL exactly.
  return { uri: uri.trim(), transport, channel };
}
export function streamSummary(stream: DiscoveredStream): string {
  const url = new URL(stream.uri);
  // Never show userinfo, query tokens, unique identifiers or raw camera responses.
  return `${url.protocol}//${url.hostname}${url.port ? `:${url.port}` : ""} · canal ${stream.channel + 1} · ${stream.transport === "auto" ? "negociação automática" : stream.transport.toUpperCase()}`;
}
export function vlcOptions(transport: RtspTransport): string[] {
  const options = ["--network-caching=500"];
  if (transport === "tcp") options.push("--rtsp-tcp");
  if (transport === "udp") options.push("--no-rtsp-tcp");
  return options;
}
export async function requestJson(
  gateway: string,
  stage: DiscoveryStage | "session",
  fetcher: typeof fetch,
  parent: AbortSignal | undefined,
  timeoutMs: number,
): Promise<unknown> {
  const issue = validateGateway(gateway);
  if (issue) throw new DiscoveryError("gateway", issue);
  if (parent?.aborted) throw cancelled();
  const controller = new AbortController();
  const endpoint = {
    device: "getdeviceattr",
    media: "getmediainfo",
    session: "enterrecorder",
  }[stage];
  const label = {
    device: "identificação",
    media: "mídia",
    session: "abertura da sessão",
  }[stage];
  let timer: ReturnType<typeof setTimeout> | undefined;
  let abortParent: (() => void) | undefined;
  const deadline = new Promise<never>((_resolve, reject) => {
    abortParent = () => {
      controller.abort();
      reject(cancelled());
    };
    parent?.addEventListener("abort", abortParent, { once: true });
    timer = setTimeout(() => {
      controller.abort();
      reject(
        new DiscoveryError(
          `${stage}-timeout`,
          `A operação de ${label} não respondeu no prazo. O Wi-Fi estar conectado não confirma acesso HTTP à câmera; este firmware pode exigir outro protocolo ou roteamento pela rede local.${stage === "session" ? " A câmera pode ter recebido a abertura de sessão mesmo sem confirmação; o player não será iniciado nesta tentativa." : ""}`,
        ),
      );
    }, timeoutMs);
  });
  const operation = (async () => {
    const response = await fetcher(`http://${gateway}/app/${endpoint}`, {
      method: "GET",
      signal: controller.signal,
      redirect: "error",
      credentials: "omit",
      headers: { Accept: "application/json" },
    });
    if (response.status !== 200) {
      const auth = response.status === 401 || response.status === 403;
      throw new DiscoveryError(
        `${stage}-http-${response.status}`,
        auth
          ? `A câmera exige autorização para esta consulta (HTTP ${response.status}). Não vamos enviar a senha Wi-Fi como login de vídeo.`
          : `A operação de ${label} retornou HTTP ${response.status}. O firmware pode não usar este protocolo.`,
      );
    }
    if (response.url && new URL(response.url).hostname !== gateway)
      throw new DiscoveryError(
        `${stage}-redirect`,
        "A resposta veio de outro endereço; consulta interrompida.",
      );
    const text = await response.text();
    if (text.length > 65536)
      throw new DiscoveryError(
        `${stage}-size`,
        "A resposta ultrapassou o limite de descoberta.",
      );
    try {
      return JSON.parse(text) as unknown;
    } catch {
      throw new DiscoveryError(
        `${stage}-json`,
        "A câmera respondeu, mas não retornou JSON válido para descoberta.",
      );
    }
  })();
  try {
    const result = await Promise.race([deadline, operation]);
    if (parent?.aborted) throw cancelled();
    return result;
  } catch (error) {
    if (parent?.aborted) throw cancelled();
    if (error instanceof DiscoveryError) throw error;
    throw new DiscoveryError(
      `${stage}-network`,
      `Não foi possível concluir ${label} no gateway da câmera. A rede local pode estar inacessível ao app ou este firmware pode usar outro protocolo. Nenhuma senha foi enviada.`,
    );
  } finally {
    if (timer) clearTimeout(timer);
    if (abortParent) parent?.removeEventListener("abort", abortParent);
    controller.abort();
  }
}
export async function discoverStream(options: {
  gateway: string;
  signal?: AbortSignal;
  fetcher?: typeof fetch;
  timeoutMs?: number;
  onStage?: (stage: DiscoveryStage) => void;
}): Promise<DiscoveredStream> {
  const gateway = options.gateway.trim();
  const issue = validateGateway(gateway);
  if (issue) throw new DiscoveryError("gateway", issue);
  if (options.signal?.aborted) throw cancelled();
  const fetcher = options.fetcher ?? fetch;
  const timeoutMs = options.timeoutMs ?? 8000;
  options.onStage?.("device");
  const device = parseDevice(
    await requestJson(gateway, "device", fetcher, options.signal, timeoutMs),
  );
  if (options.signal?.aborted) throw cancelled();
  options.onStage?.("media");
  const response = await requestJson(
    gateway,
    "media",
    fetcher,
    options.signal,
    timeoutMs,
  );
  if (options.signal?.aborted) throw cancelled();
  return parseMedia(response, gateway, device.channel);
}
