import type { SessionStatus } from "./model";

export const VIDEO_CONNECT_TIMEOUT_MS = 25_000;
export const VIDEO_STALL_TIMEOUT_MS = 15_000;

export type PlaybackState = { status: SessionStatus; detail?: string };
type VideoSize = { width?: unknown; height?: unknown } | null | undefined;

/** Track metadata plus an advancing clock is evidence of playback, not proof
 * that decoded pixels have appeared on the Android surface. */
export class PlaybackMonitor {
  private state: PlaybackState = { status: "connecting" };
  private terminal = false;
  private videoTrack = false;
  private lastTime = 0;
  private lastAdvanceAt: number | null = null;
  private lastHealthyAt: number | null = null;

  constructor(private readonly startedAt: number) {}

  snapshot(): PlaybackState {
    return { ...this.state };
  }

  noteVideo(size: VideoSize, now: number): void {
    this.tick(now);
    if (this.terminal) return;
    this.videoTrack =
      typeof size?.width === "number" &&
      Number.isFinite(size.width) &&
      size.width > 0 &&
      typeof size?.height === "number" &&
      Number.isFinite(size.height) &&
      size.height > 0;
    if (!this.videoTrack) {
      this.state = { status: "connecting" };
      return;
    }
    if (
      this.lastAdvanceAt !== null &&
      now - this.lastAdvanceAt < VIDEO_STALL_TIMEOUT_MS
    ) {
      this.lastHealthyAt = this.lastAdvanceAt;
      this.state = { status: "playing" };
    }
  }

  noteProgress(time: unknown, now: number): void {
    this.tick(now);
    if (
      this.terminal ||
      typeof time !== "number" ||
      !Number.isFinite(time) ||
      time < 0
    )
      return;
    if (time <= this.lastTime) return;
    this.lastTime = time;
    this.lastAdvanceAt = now;
    if (this.videoTrack) {
      this.lastHealthyAt = now;
      this.state = { status: "playing" };
    }
  }

  buffering(): void {
    if (!this.terminal) this.state = { status: "connecting" };
  }

  tick(now: number): void {
    if (this.terminal) return;
    if (this.lastHealthyAt !== null) {
      if (now - this.lastHealthyAt >= VIDEO_STALL_TIMEOUT_MS) {
        this.fail(
          "O player deixou de confirmar progresso de vídeo. Pare e reconecte; confira a rede e o endereço de transmissão.",
        );
      }
    } else if (now - this.startedAt >= VIDEO_CONNECT_TIMEOUT_MS) {
      this.fail(
        "O player não confirmou uma faixa de vídeo com progresso em 25 segundos. Estar no Wi-Fi não confirma transmissão. Confira o endereço e a compatibilidade da câmera.",
      );
    }
  }

  fail(detail: string): void {
    if (this.terminal) return;
    this.terminal = true;
    this.state = { status: "error", detail };
  }

  stop(): void {
    if (this.terminal) return;
    this.terminal = true;
    this.state = { status: "idle" };
  }
}
