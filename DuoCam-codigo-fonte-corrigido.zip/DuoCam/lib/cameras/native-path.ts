export function nativeFileUri(path: string): string {
  if (path.startsWith("file://") || path.startsWith("content://")) return path;
  if (path.startsWith("/")) return `file://${path}`;
  throw new Error("O player não retornou um caminho local válido.");
}
