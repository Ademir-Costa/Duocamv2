import AsyncStorage from "@react-native-async-storage/async-storage";
import { Platform } from "react-native";
import * as FileSystem from "expo-file-system/legacy";

import {
  extensionFromName,
  fileNameFromUrl,
  isHttpUrl,
  mediaKindFromName,
  safeFileName,
  type MediaKind,
} from "./utils";

export type MediaItem = {
  id: string;
  cameraId: "1" | "2";
  cameraName: string;
  kind: "photo" | "video";
  uri: string;
  createdAt: string;
  name: string;
};

const MEDIA_INDEX_KEY = "duocam.media.index.v1";
const MEDIA_DIRECTORY_NAME = "duocam-media";
const RECORDINGS_DIRECTORY_NAME = "recordings";
const PHOTOS_DIRECTORY_NAME = "photos";
const DOWNLOADS_DIRECTORY_NAME = "downloads";

function assertNativeFileAccess(): void {
  if (Platform.OS === "web") {
    throw new Error(
      "A biblioteca de arquivos locais está disponível somente no app Android ou iOS.",
    );
  }
}

function makeId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function isMediaItem(value: unknown): value is MediaItem {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<MediaItem>;
  return (
    typeof item.id === "string" &&
    (item.cameraId === "1" || item.cameraId === "2") &&
    typeof item.cameraName === "string" &&
    (item.kind === "photo" || item.kind === "video") &&
    typeof item.uri === "string" &&
    typeof item.createdAt === "string" &&
    typeof item.name === "string"
  );
}

async function readIndex(): Promise<MediaItem[]> {
  const raw = await AsyncStorage.getItem(MEDIA_INDEX_KEY);
  if (!raw) return [];

  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(isMediaItem)
      .sort(
        (first, second) =>
          Date.parse(second.createdAt) - Date.parse(first.createdAt),
      );
  } catch {
    return [];
  }
}

async function writeIndex(items: MediaItem[]): Promise<void> {
  const ordered = [...items].sort(
    (first, second) =>
      Date.parse(second.createdAt) - Date.parse(first.createdAt),
  );
  await AsyncStorage.setItem(MEDIA_INDEX_KEY, JSON.stringify(ordered));
}

function documentDirectory(): string {
  const directory = FileSystem.documentDirectory;
  if (!directory) {
    throw new Error(
      "O diretório de documentos do aplicativo não está disponível neste dispositivo.",
    );
  }
  return directory;
}

async function ensureDirectory(uri: string): Promise<void> {
  const info = await FileSystem.getInfoAsync(uri);
  if (!info.exists) {
    await FileSystem.makeDirectoryAsync(uri, { intermediates: true });
  }
}

async function getMediaDirectory(): Promise<string> {
  assertNativeFileAccess();
  const directory = `${documentDirectory()}${MEDIA_DIRECTORY_NAME}/`;
  await ensureDirectory(directory);
  return directory;
}

async function getKindDirectory(kind: MediaKind): Promise<string> {
  const root = await getMediaDirectory();
  const directoryName =
    kind === "video" ? RECORDINGS_DIRECTORY_NAME : PHOTOS_DIRECTORY_NAME;
  const directory = `${root}${directoryName}/`;
  await ensureDirectory(directory);
  return directory;
}

function nativePathFromUri(uri: string): string {
  return uri.startsWith("file://") ? uri.slice("file://".length) : uri;
}

function isInsideDirectory(uri: string, directory: string): boolean {
  return uri.startsWith(directory);
}

function inferKind(uri: string, name: string): MediaKind {
  const extension = extensionFromName(name) || extensionFromName(uri);
  return mediaKindFromName(extension ? `arquivo.${extension}` : name || uri);
}

/** Returns the app-private video recording directory as a native filesystem path (without file://). */
export async function getRecordingDirectory(): Promise<string> {
  const directory = await getKindDirectory("video");
  return nativePathFromUri(directory);
}

/**
 * Allocates an app-private capture destination. The camera/player should write to this URI and call
 * addMedia only after its operation succeeds. This URI intentionally keeps file:// for normal Expo APIs.
 */
export async function createCapturePath(
  kind: "photo" | "video",
): Promise<string> {
  const directory = await getKindDirectory(kind);
  const suffix = kind === "photo" ? "jpg" : "mp4";
  return `${directory}${kind}-${new Date().toISOString().replace(/[:.]/g, "-")}-${makeId()}.${suffix}`;
}

/** Reads only persisted entries whose local native files still exist. */
export async function getMedia(): Promise<MediaItem[]> {
  const indexed = await readIndex();
  if (Platform.OS === "web" || indexed.length === 0) return indexed;

  const existing: MediaItem[] = [];
  for (const item of indexed) {
    try {
      const info = await FileSystem.getInfoAsync(item.uri);
      if (info.exists && !info.isDirectory) existing.push(item);
    } catch {
      // A malformed/stale file reference is omitted instead of being presented as available media.
    }
  }

  if (existing.length !== indexed.length) await writeIndex(existing);
  return existing;
}

/**
 * Registers a file that was genuinely created or selected by a native operation.
 * Cache files are moved into Documents when possible; other external files are copied there.
 */
export async function addMedia(
  input: Omit<MediaItem, "id" | "createdAt">,
): Promise<MediaItem> {
  assertNativeFileAccess();
  if (input.cameraId !== "1" && input.cameraId !== "2") {
    throw new Error(
      "A mídia precisa estar associada à Câmera 1 ou à Câmera 2.",
    );
  }
  if (input.kind !== "photo" && input.kind !== "video") {
    throw new Error("O tipo de mídia informado não é suportado.");
  }
  if (!input.uri.startsWith("file://") && !input.uri.startsWith("content://")) {
    throw new Error(
      "A mídia precisa apontar para um arquivo local criado ou escolhido no dispositivo.",
    );
  }

  const sourceInfo = await FileSystem.getInfoAsync(input.uri);
  if (!sourceInfo.exists || sourceInfo.isDirectory) {
    throw new Error("O arquivo de mídia não existe mais no dispositivo.");
  }

  const root = await getMediaDirectory();
  const originalName = safeFileName(input.name || "midia", input.kind);
  const extension =
    extensionFromName(originalName) || (input.kind === "photo" ? "jpg" : "mp4");
  const item: MediaItem = {
    id: makeId(),
    cameraId: input.cameraId,
    cameraName: input.cameraName.trim() || `Câmera ${input.cameraId}`,
    kind: input.kind,
    uri: input.uri,
    createdAt: new Date().toISOString(),
    name: originalName,
  };

  if (!isInsideDirectory(input.uri, root)) {
    const destinationDirectory = await getKindDirectory(input.kind);
    const destination = `${destinationDirectory}${item.id}.${extension}`;
    const cacheDirectory = FileSystem.cacheDirectory;

    try {
      if (cacheDirectory && isInsideDirectory(input.uri, cacheDirectory)) {
        await FileSystem.moveAsync({ from: input.uri, to: destination });
      } else {
        await FileSystem.copyAsync({ from: input.uri, to: destination });
      }
    } catch (error) {
      throw new Error(
        `Não foi possível guardar a mídia na biblioteca local: ${error instanceof Error ? error.message : "erro de arquivo"}`,
      );
    }
    item.uri = destination;
  }

  const finalInfo = await FileSystem.getInfoAsync(item.uri);
  if (!finalInfo.exists || finalInfo.isDirectory) {
    throw new Error("A mídia não foi salva corretamente na biblioteca local.");
  }

  const current = await readIndex();
  await writeIndex([item, ...current.filter((entry) => entry.id !== item.id)]);
  return item;
}

/** Removes both the persisted index entry and its app-private local file. */
export async function deleteMedia(id: string): Promise<void> {
  const current = await readIndex();
  const item = current.find((entry) => entry.id === id);
  if (!item) return;

  if (Platform.OS !== "web") {
    const root = await getMediaDirectory();
    if (isInsideDirectory(item.uri, root)) {
      const info = await FileSystem.getInfoAsync(item.uri);
      if (info.exists)
        await FileSystem.deleteAsync(item.uri, { idempotent: true });
    }
  }

  await writeIndex(current.filter((entry) => entry.id !== id));
}

/** Downloads a user-supplied, direct HTTP(S) media URL into the local library. */
export async function downloadMedia(
  url: string,
  cameraId: "1" | "2",
  cameraName: string,
): Promise<MediaItem> {
  assertNativeFileAccess();
  const directUrl = url.trim();
  if (!isHttpUrl(directUrl)) {
    throw new Error(
      "Informe uma URL direta HTTP ou HTTPS para um arquivo de mídia.",
    );
  }
  if (cameraId !== "1" && cameraId !== "2") {
    throw new Error("Escolha a Câmera 1 ou a Câmera 2.");
  }

  const guessedName = fileNameFromUrl(directUrl);
  const kind = inferKind(directUrl, guessedName);
  const downloadsDirectory = `${await getMediaDirectory()}${DOWNLOADS_DIRECTORY_NAME}/`;
  await ensureDirectory(downloadsDirectory);
  const temporaryUri = `${downloadsDirectory}${makeId()}-${guessedName}`;

  try {
    const result = await FileSystem.downloadAsync(directUrl, temporaryUri);
    if (
      typeof result.status === "number" &&
      (result.status < 200 || result.status >= 300)
    ) {
      await FileSystem.deleteAsync(temporaryUri, { idempotent: true });
      throw new Error(`O servidor respondeu com status ${result.status}.`);
    }

    return await addMedia({
      cameraId,
      cameraName: cameraName.trim() || `Câmera ${cameraId}`,
      kind,
      uri: result.uri,
      name: guessedName,
    });
  } catch (error) {
    try {
      await FileSystem.deleteAsync(temporaryUri, { idempotent: true });
    } catch {
      // Preserve the original download error; an incomplete file is best-effort cleanup only.
    }
    throw error instanceof Error
      ? error
      : new Error(
          "Não foi possível baixar o arquivo diretamente para a biblioteca.",
        );
  }
}
