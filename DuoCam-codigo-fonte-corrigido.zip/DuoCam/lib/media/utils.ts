export type MediaKind = "photo" | "video";

const PHOTO_EXTENSIONS = new Set([
  "avif",
  "bmp",
  "gif",
  "heic",
  "heif",
  "jpeg",
  "jpg",
  "png",
  "webp",
]);
const VIDEO_EXTENSIONS = new Set([
  "3gp",
  "avi",
  "m4v",
  "mkv",
  "mov",
  "mp4",
  "mpeg",
  "mpg",
  "webm",
]);

/** Accepts only a direct HTTP(S) address provided by the person using the app. */
export function isHttpUrl(value: string): boolean {
  const candidate = value.trim();
  if (!candidate) return false;

  try {
    const parsed = new URL(candidate);
    return (
      (parsed.protocol === "http:" || parsed.protocol === "https:") &&
      Boolean(parsed.hostname)
    );
  } catch {
    return false;
  }
}

export function mediaKindFromName(name: string): MediaKind {
  const extension = extensionFromName(name);
  return PHOTO_EXTENSIONS.has(extension) ? "photo" : "video";
}

export function extensionFromName(name: string): string {
  const withoutQuery = name.split(/[?#]/, 1)[0] ?? "";
  const lastPart = withoutQuery.split("/").pop() ?? "";
  const match = /\.([a-z0-9]{1,10})$/i.exec(lastPart);
  return match?.[1]?.toLowerCase() ?? "";
}

export function fileNameFromUrl(
  url: string,
  fallbackKind: MediaKind = "video",
): string {
  try {
    const lastPart = new URL(url).pathname.split("/").filter(Boolean).pop();
    if (lastPart)
      return safeFileName(decodeURIComponent(lastPart), fallbackKind);
  } catch {
    // The caller validates direct-download URLs separately. Keep a predictable fallback here.
  }
  return safeFileName("midia", fallbackKind);
}

/**
 * Produces a display/file-safe basename while keeping a meaningful extension.
 * It deliberately avoids path separators so names cannot escape the app directory.
 */
export function safeFileName(
  value: string,
  fallbackKind: MediaKind = "video",
): string {
  const fallbackExtension = fallbackKind === "photo" ? "jpg" : "mp4";
  const cleaned = value
    .trim()
    .replace(/[\\/]+/g, "-")
    .replace(/\.\.+/g, "")
    .replace(/[:*?"<>|\u0000-\u001f]/g, "-")
    .replace(/\s+/g, " ")
    .replace(/^-+/, "")
    .slice(0, 120);

  const withBaseName = cleaned || `midia.${fallbackExtension}`;
  if (extensionFromName(withBaseName)) return withBaseName;
  return `${withBaseName}.${fallbackExtension}`;
}

export function isKnownMediaExtension(name: string): boolean {
  const extension = extensionFromName(name);
  return PHOTO_EXTENSIONS.has(extension) || VIDEO_EXTENSIONS.has(extension);
}
