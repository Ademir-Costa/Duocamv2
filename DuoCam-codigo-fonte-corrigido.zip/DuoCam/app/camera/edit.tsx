import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Button,
  C,
  Eyebrow,
  IconButton,
  Notice,
  styles,
} from "@/components/duocam/ui";
import { useCameras } from "@/lib/cameras/context";
import {
  cameraGateway,
  cameraMode,
  cameraTransport,
  type Camera,
  type RtspTransport,
} from "@/lib/cameras/model";
export default function EditCamera() {
  const { ready } = useCameras();
  if (!ready)
    return (
      <SafeAreaView
        style={[styles.page, { justifyContent: "center", padding: 24 }]}
      >
        <Text style={styles.body}>Carregando suas câmeras salvas…</Text>
      </SafeAreaView>
    );
  return <EditCameraForm />;
}
function EditCameraForm() {
  const params = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { cameras, saveCamera, ready } = useCameras();
  const found = cameras.find((c) => c.id === params.id) ?? cameras[0];
  const [draft, setDraft] = useState<Camera>({ ...found });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const mode = cameraMode(draft);
  async function save() {
    setBusy(true);
    setError("");
    try {
      await saveCamera(draft);
      router.back();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não foi possível salvar.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <SafeAreaView
      style={styles.page}
      edges={["top", "left", "right", "bottom"]}
    >
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={[styles.content, { paddingTop: 14 }]}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 15 }}>
            <IconButton
              icon="arrow-back"
              label="Voltar"
              onPress={() => router.back()}
            />
            <Eyebrow>CONFIGURAÇÃO · CÂMERA 0{draft.id}</Eyebrow>
          </View>
          <View style={{ gap: 9 }}>
            <Text style={styles.title}>{"Sua câmera.\nSua conexão."}</Text>
            <Text style={styles.body}>
              Conecte ao Wi-Fi da V100 pelo Android. A senha fica nos ajustes da
              rede; não é enviada como login de vídeo.
            </Text>
          </View>
          <View style={{ gap: 9 }}>
            <Text style={styles.label}>NOME DA CÂMERA</Text>
            <TextInput
              accessibilityLabel="Nome da câmera"
              style={styles.input}
              value={draft.name}
              onChangeText={(name) => setDraft((d) => ({ ...d, name }))}
              maxLength={40}
              placeholder="Ex.: Câmera frontal"
              placeholderTextColor={C.muted}
              editable={!busy}
            />
          </View>
          <View style={{ gap: 9 }}>
            <Text style={styles.label}>REDE WI-FI (SSID)</Text>
            <TextInput
              accessibilityLabel="Nome da rede Wi-Fi"
              style={styles.input}
              value={draft.ssid}
              onChangeText={(ssid) => setDraft((d) => ({ ...d, ssid }))}
              autoCapitalize="none"
              autoCorrect={false}
              maxLength={32}
              placeholder="Ex.: MITSUBISHICAMTRA"
              placeholderTextColor={C.muted}
              editable={!busy}
            />
            <Text style={styles.body}>
              Informe o nome real da rede. Este cadastro não verifica qual Wi-Fi
              está conectado.
            </Text>
          </View>
          <View style={{ gap: 10 }}>
            <Text style={styles.label}>COMO OBTER O VÍDEO</Text>
            <Button
              title="Descobrir V100 · experimental"
              icon="search-outline"
              variant={mode === "discovery" ? "primary" : "secondary"}
              disabled={busy}
              onPress={() =>
                setDraft((d) => ({
                  ...d,
                  connectionMode: "discovery",
                  gateway: cameraGateway(d),
                  transport: "auto",
                }))
              }
            />
            <Button
              title="Usar URL manual"
              icon="link-outline"
              variant={mode === "manual" ? "primary" : "secondary"}
              disabled={busy}
              onPress={() =>
                setDraft((d) => ({ ...d, connectionMode: "manual" }))
              }
            />
          </View>
          {mode === "discovery" ? (
            <View style={{ gap: 9 }}>
              <Text style={styles.label}>GATEWAY DA CÂMERA</Text>
              <TextInput
                accessibilityLabel="Gateway IPv4 privado da câmera"
                style={[styles.input, { fontFamily: "monospace" }]}
                value={cameraGateway(draft)}
                onChangeText={(gateway) => setDraft((d) => ({ ...d, gateway }))}
                keyboardType="decimal-pad"
                autoCapitalize="none"
                autoCorrect={false}
                maxLength={15}
                placeholder="192.168.169.1"
                placeholderTextColor={C.muted}
                editable={!busy}
              />
              <Text style={styles.body}>
                Use o endereço “Roteador” mostrado nos detalhes do Wi-Fi. Não
                inclua porta, rtsp:// ou senha.
              </Text>
              <Notice>
                A descoberta consulta identificação e mídia por HTTP/80. Só abre
                o vídeo após receber uma URL válida. Não transforma a porta de
                mensagens em vídeo. A abertura de sessão abaixo é opcional e
                desativada por padrão.
              </Notice>
              <Button
                title={
                  draft.prepareSession
                    ? "Abertura de sessão · ATIVADA"
                    : "Abertura de sessão · DESATIVADA"
                }
                icon={
                  draft.prepareSession
                    ? "checkmark-circle-outline"
                    : "ellipse-outline"
                }
                variant={draft.prepareSession ? "primary" : "secondary"}
                disabled={busy}
                onPress={() =>
                  setDraft((d) => ({ ...d, prepareSession: !d.prepareSession }))
                }
              />
              <Text style={styles.body}>
                Quando ativada, envia /app/enterrecorder para abrir o
                modo/sessão de visualização antes do player. Não é apenas
                leitura e não envia a senha Wi-Fi. Cancelar impede iniciar o
                player, mas não desfaz uma sessão que a câmera já aceitou. Não
                enviamos saída de sessão automaticamente.
              </Text>
              {!!draft.url && (
                <Text style={{ color: C.muted, fontSize: 12 }}>
                  Sua URL manual continua salva, mas não será usada no modo de
                  descoberta.
                </Text>
              )}
            </View>
          ) : (
            <View style={{ gap: 9 }}>
              <Text style={styles.label}>ENDEREÇO DE VÍDEO</Text>
              <TextInput
                accessibilityLabel="Endereço de vídeo da câmera"
                style={[
                  styles.input,
                  { fontFamily: "monospace", fontSize: 13 },
                ]}
                value={draft.url}
                onChangeText={(url) => setDraft((d) => ({ ...d, url }))}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="url"
                placeholder="rtsp://IP-DA-CAMERA/caminho"
                placeholderTextColor={C.muted}
                editable={!busy}
              />
              <Text style={styles.body}>
                Use a URL completa confirmada para o vídeo. Uma porta TCP aberta
                não comprova que exista RTSP nela. Você pode salvar sem URL e
                preencher depois.
              </Text>
            </View>
          )}
          <View style={{ gap: 10 }}>
            <Text style={styles.label}>TRANSPORTE RTSP</Text>
            <View style={{ flexDirection: "row", gap: 7 }}>
              {(["auto", "tcp", "udp"] as RtspTransport[]).map((value) => (
                <Button
                  key={value}
                  title={value === "auto" ? "Automático" : value.toUpperCase()}
                  style={{ flex: 1, paddingHorizontal: 7 }}
                  disabled={busy}
                  variant={
                    cameraTransport(draft) === value ? "primary" : "secondary"
                  }
                  onPress={() => setDraft((d) => ({ ...d, transport: value }))}
                />
              ))}
            </View>
            <Text style={styles.body}>
              Automático segue TCP/UDP informado pela câmera; se não informado,
              deixa o VLC negociar. Não há troca automática silenciosa ao
              falhar.
            </Text>
          </View>
          {!!error && <Notice danger>{error}</Notice>}
          <Button
            title={busy ? "Salvando…" : "Salvar câmera"}
            icon="checkmark-outline"
            onPress={save}
            disabled={busy || !ready}
          />
          <Text style={{ color: C.muted, fontSize: 11, lineHeight: 18 }}>
            Dados salvos neste dispositivo. Esta versão não aceita credenciais
            na URL nem altera senha, formata cartão ou controla sua gravação. A
            abertura de sessão é a única operação de preparação opcional.
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
