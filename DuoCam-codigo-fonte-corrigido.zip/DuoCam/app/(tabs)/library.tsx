import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { downloadMedia, getMedia, type MediaItem } from "@/lib/media/storage";
import { isHttpUrl } from "@/lib/media/utils";

type Filter = "all" | "photo" | "video";

const COLORS = {
  background: "#10141B",
  surface: "#1B222D",
  surfaceRaised: "#232C38",
  amber: "#F4B545",
  text: "#F2F4F7",
  muted: "#8D99AB",
  line: "#324051",
  danger: "#E77272",
};

const FILTERS: Array<{
  key: Filter;
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
}> = [
  { key: "all", label: "Tudo", icon: "albums-outline" },
  { key: "photo", label: "Fotos", icon: "image-outline" },
  { key: "video", label: "Vídeos", icon: "videocam-outline" },
];

function formatDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Data indisponível";
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function MediaThumbnail({ item }: { item: MediaItem }) {
  if (item.kind === "photo") {
    return (
      <Image
        accessibilityLabel={`Foto ${item.name}`}
        source={{ uri: item.uri }}
        style={styles.thumbnail}
      />
    );
  }

  return (
    <View style={[styles.thumbnail, styles.videoThumbnail]}>
      <Ionicons color={COLORS.amber} name="play-circle-outline" size={32} />
      <Text style={styles.videoMark}>VÍDEO</Text>
    </View>
  );
}

export default function LibraryScreen() {
  const router = useRouter();
  const [items, setItems] = useState<MediaItem[]>([]);
  const [filter, setFilter] = useState<Filter>("all");
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [downloadVisible, setDownloadVisible] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState("");
  const [cameraId, setCameraId] = useState<"1" | "2">("1");
  const [downloadBusy, setDownloadBusy] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const reload = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);
    setError(null);
    try {
      setItems(await getMedia());
    } catch (cause) {
      setError(
        cause instanceof Error
          ? cause.message
          : "Não foi possível abrir a biblioteca local.",
      );
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      void reload();
    }, [reload]),
  );

  const visibleItems = useMemo(
    () =>
      filter === "all" ? items : items.filter((item) => item.kind === filter),
    [filter, items],
  );

  const openDownload = () => {
    setDownloadError(null);
    setDownloadVisible(true);
  };

  const closeDownload = () => {
    if (downloadBusy) return;
    setDownloadVisible(false);
    setDownloadError(null);
  };

  const handleDownload = async () => {
    if (Platform.OS === "web") {
      setDownloadError(
        "A prévia Web não acessa o sistema de arquivos nativo. Baixe no app Android ou iOS.",
      );
      return;
    }
    if (!isHttpUrl(downloadUrl)) {
      setDownloadError(
        "Informe uma URL direta que comece com http:// ou https://.",
      );
      return;
    }

    setDownloadBusy(true);
    setDownloadError(null);
    try {
      await downloadMedia(downloadUrl, cameraId, `Câmera ${cameraId}`);
      setDownloadUrl("");
      setDownloadVisible(false);
      await reload();
    } catch (cause) {
      setDownloadError(
        cause instanceof Error
          ? cause.message
          : "Não foi possível baixar esse arquivo.",
      );
    } finally {
      setDownloadBusy(false);
    }
  };

  return (
    <SafeAreaView edges={["top", "left", "right"]} style={styles.safeArea}>
      <View style={styles.screen}>
        <FlatList
          data={visibleItems}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          refreshing={refreshing}
          onRefresh={() => void reload(true)}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            <View>
              <View style={styles.header}>
                <View>
                  <Text style={styles.eyebrow}>ARQUIVOS LOCAIS</Text>
                  <Text style={styles.title}>Biblioteca</Text>
                  <Text style={styles.subtitle}>
                    Fotos e gravações salvas neste aparelho.
                  </Text>
                </View>
                <Pressable
                  accessibilityLabel="Baixar arquivo por URL"
                  accessibilityRole="button"
                  onPress={openDownload}
                  style={({ pressed }) => [
                    styles.downloadButton,
                    pressed && styles.pressed,
                  ]}
                >
                  <Ionicons
                    color={COLORS.background}
                    name="download-outline"
                    size={22}
                  />
                  <Text style={styles.downloadButtonText}>Baixar</Text>
                </Pressable>
              </View>

              {Platform.OS === "web" ? (
                <View style={styles.webNotice}>
                  <Ionicons
                    color={COLORS.amber}
                    name="desktop-outline"
                    size={18}
                  />
                  <Text style={styles.webNoticeText}>
                    A prévia Web mostra a interface, mas não baixa, grava ou
                    valida arquivos locais.
                  </Text>
                </View>
              ) : null}

              <View style={styles.filterRow} accessibilityRole="tablist">
                {FILTERS.map((option) => {
                  const selected = filter === option.key;
                  return (
                    <Pressable
                      key={option.key}
                      accessibilityRole="tab"
                      accessibilityState={{ selected }}
                      onPress={() => setFilter(option.key)}
                      style={({ pressed }) => [
                        styles.filterButton,
                        selected && styles.filterButtonSelected,
                        pressed && styles.pressed,
                      ]}
                    >
                      <Ionicons
                        color={selected ? COLORS.amber : COLORS.muted}
                        name={option.icon}
                        size={17}
                      />
                      <Text
                        style={[
                          styles.filterText,
                          selected && styles.filterTextSelected,
                        ]}
                      >
                        {option.label}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>

              {error ? (
                <View style={styles.errorBox}>
                  <Ionicons
                    color={COLORS.danger}
                    name="alert-circle-outline"
                    size={20}
                  />
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              ) : null}

              {!loading ? (
                <Text style={styles.countText}>
                  {visibleItems.length} arquivo(s)
                </Text>
              ) : null}
            </View>
          }
          renderItem={({ item }) => (
            <Pressable
              accessibilityHint="Abre a mídia para reprodução, compartilhamento e exclusão"
              accessibilityLabel={`${item.kind === "photo" ? "Foto" : "Vídeo"}: ${item.name}`}
              accessibilityRole="button"
              onPress={() =>
                router.push({ pathname: "/media", params: { id: item.id } })
              }
              style={({ pressed }) => [
                styles.mediaCard,
                pressed && styles.pressed,
              ]}
            >
              <MediaThumbnail item={item} />
              <View style={styles.cardBody}>
                <View style={styles.cardTitleRow}>
                  <Text numberOfLines={1} style={styles.cardTitle}>
                    {item.name}
                  </Text>
                  <Ionicons
                    color={COLORS.muted}
                    name="chevron-forward"
                    size={18}
                  />
                </View>
                <Text numberOfLines={1} style={styles.cardMeta}>
                  {item.cameraName} · {formatDate(item.createdAt)}
                </Text>
                <View style={styles.kindPill}>
                  <Ionicons
                    color={COLORS.amber}
                    name={
                      item.kind === "photo"
                        ? "image-outline"
                        : "videocam-outline"
                    }
                    size={13}
                  />
                  <Text style={styles.kindText}>
                    {item.kind === "photo" ? "FOTO" : "VÍDEO"}
                  </Text>
                </View>
              </View>
            </Pressable>
          )}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              {loading ? (
                <ActivityIndicator color={COLORS.amber} size="large" />
              ) : (
                <>
                  <View style={styles.emptyIcon}>
                    <Ionicons
                      color={COLORS.amber}
                      name={
                        filter === "photo"
                          ? "image-outline"
                          : filter === "video"
                            ? "videocam-outline"
                            : "folder-open-outline"
                      }
                      size={32}
                    />
                  </View>
                  <Text style={styles.emptyTitle}>
                    {filter === "all"
                      ? "Ainda não há arquivos"
                      : `Nenhuma ${filter === "photo" ? "foto" : "gravação"} aqui`}
                  </Text>
                  <Text style={styles.emptyText}>
                    {filter === "all"
                      ? "Capturas concluídas e downloads diretos aparecerão nesta biblioteca."
                      : "Altere o filtro para ver outros arquivos salvos no aparelho."}
                  </Text>
                  {filter === "all" ? (
                    <Pressable
                      onPress={openDownload}
                      style={({ pressed }) => [
                        styles.emptyAction,
                        pressed && styles.pressed,
                      ]}
                    >
                      <Ionicons
                        color={COLORS.background}
                        name="download-outline"
                        size={18}
                      />
                      <Text style={styles.emptyActionText}>Baixar por URL</Text>
                    </Pressable>
                  ) : null}
                </>
              )}
            </View>
          }
        />
      </View>

      <Modal
        animationType="fade"
        transparent
        visible={downloadVisible}
        onRequestClose={closeDownload}
      >
        <View style={styles.modalRoot}>
          <Pressable
            accessibilityLabel="Fechar download"
            onPress={closeDownload}
            style={styles.modalScrim}
          />
          <View accessibilityViewIsModal style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalEyebrow}>DOWNLOAD DIRETO</Text>
                <Text style={styles.modalTitle}>Adicionar arquivo</Text>
              </View>
              <Pressable
                accessibilityLabel="Fechar"
                disabled={downloadBusy}
                onPress={closeDownload}
                style={styles.closeButton}
              >
                <Ionicons color={COLORS.text} name="close" size={23} />
              </Pressable>
            </View>

            <Text style={styles.fieldLabel}>URL do arquivo</Text>
            <TextInput
              autoCapitalize="none"
              autoCorrect={false}
              editable={!downloadBusy}
              keyboardType="url"
              onChangeText={setDownloadUrl}
              placeholder="https://…/arquivo.mp4"
              placeholderTextColor={COLORS.muted}
              selectionColor={COLORS.amber}
              style={styles.input}
              value={downloadUrl}
            />
            <Text style={styles.helperText}>
              Use apenas uma URL HTTP(S) direta de foto ou vídeo. Nenhum arquivo
              passa por cloud.
            </Text>

            <Text style={[styles.fieldLabel, styles.cameraLabel]}>
              Associar à
            </Text>
            <View style={styles.cameraRow}>
              {(["1", "2"] as const).map((id) => {
                const selected = cameraId === id;
                return (
                  <Pressable
                    key={id}
                    accessibilityRole="radio"
                    accessibilityState={{ selected }}
                    disabled={downloadBusy}
                    onPress={() => setCameraId(id)}
                    style={[
                      styles.cameraChoice,
                      selected && styles.cameraChoiceSelected,
                    ]}
                  >
                    <Text
                      style={[
                        styles.cameraChoiceIndex,
                        selected && styles.cameraChoiceTextSelected,
                      ]}
                    >
                      0{id}
                    </Text>
                    <Text
                      style={[
                        styles.cameraChoiceText,
                        selected && styles.cameraChoiceTextSelected,
                      ]}
                    >
                      Câmera {id}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            {downloadError ? (
              <View style={styles.errorBox}>
                <Ionicons
                  color={COLORS.danger}
                  name="alert-circle-outline"
                  size={20}
                />
                <Text style={styles.errorText}>{downloadError}</Text>
              </View>
            ) : null}

            <Pressable
              accessibilityRole="button"
              disabled={downloadBusy}
              onPress={() => void handleDownload()}
              style={({ pressed }) => [
                styles.primaryAction,
                (pressed || downloadBusy) && styles.pressed,
                downloadBusy && styles.disabled,
              ]}
            >
              {downloadBusy ? (
                <ActivityIndicator color={COLORS.background} />
              ) : (
                <Ionicons
                  color={COLORS.background}
                  name="download-outline"
                  size={20}
                />
              )}
              <Text style={styles.primaryActionText}>
                {downloadBusy
                  ? "Baixando diretamente…"
                  : "Baixar para biblioteca"}
              </Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  screen: { flex: 1, width: "100%", maxWidth: 720, alignSelf: "center" },
  listContent: {
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 36,
    flexGrow: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
    alignItems: "flex-start",
  },
  eyebrow: {
    color: COLORS.amber,
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 1.2,
    marginBottom: 6,
  },
  title: {
    color: COLORS.text,
    fontSize: 30,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  subtitle: {
    color: COLORS.muted,
    fontSize: 14,
    lineHeight: 20,
    marginTop: 5,
    maxWidth: 260,
  },
  downloadButton: {
    minHeight: 46,
    paddingHorizontal: 14,
    borderRadius: 8,
    gap: 7,
    backgroundColor: COLORS.amber,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 5,
  },
  downloadButtonText: {
    color: COLORS.background,
    fontWeight: "800",
    fontSize: 14,
  },
  webNotice: {
    marginTop: 20,
    backgroundColor: "#25271F",
    borderColor: "#64572D",
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    flexDirection: "row",
    gap: 9,
    alignItems: "flex-start",
  },
  webNoticeText: { color: COLORS.text, flex: 1, fontSize: 13, lineHeight: 18 },
  filterRow: { marginTop: 22, flexDirection: "row", gap: 8 },
  filterButton: {
    flex: 1,
    minHeight: 42,
    borderRadius: 7,
    paddingHorizontal: 10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 6,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.line,
  },
  filterButtonSelected: {
    backgroundColor: "#2D2A20",
    borderColor: COLORS.amber,
  },
  filterText: { color: COLORS.muted, fontSize: 13, fontWeight: "700" },
  filterTextSelected: { color: COLORS.amber },
  countText: {
    color: COLORS.muted,
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 0.8,
    marginTop: 22,
    marginBottom: 8,
  },
  errorBox: {
    marginTop: 16,
    borderColor: "#6D373A",
    borderWidth: 1,
    backgroundColor: "#2B1F24",
    borderRadius: 8,
    padding: 11,
    flexDirection: "row",
    gap: 9,
    alignItems: "flex-start",
  },
  errorText: { color: "#FFD8D8", fontSize: 13, lineHeight: 18, flex: 1 },
  mediaCard: {
    marginTop: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: COLORS.line,
    borderRadius: 10,
    backgroundColor: COLORS.surface,
    flexDirection: "row",
    gap: 12,
    minHeight: 96,
  },
  thumbnail: {
    width: 86,
    height: 74,
    borderRadius: 6,
    backgroundColor: "#0C1016",
  },
  videoThumbnail: {
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#4C4325",
  },
  videoMark: {
    color: COLORS.muted,
    fontSize: 9,
    letterSpacing: 1,
    marginTop: 2,
    fontWeight: "800",
  },
  cardBody: { flex: 1, justifyContent: "center", minWidth: 0 },
  cardTitleRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  cardTitle: { flex: 1, color: COLORS.text, fontSize: 15, fontWeight: "700" },
  cardMeta: { color: COLORS.muted, fontSize: 12, lineHeight: 17, marginTop: 4 },
  kindPill: {
    marginTop: 8,
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    borderRadius: 4,
    backgroundColor: "#282B29",
    paddingHorizontal: 6,
    paddingVertical: 3,
  },
  kindText: {
    color: COLORS.amber,
    fontSize: 10,
    letterSpacing: 0.8,
    fontWeight: "800",
  },
  emptyState: {
    flex: 1,
    minHeight: 360,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 26,
    paddingVertical: 54,
  },
  emptyIcon: {
    height: 68,
    width: 68,
    borderRadius: 34,
    backgroundColor: COLORS.surface,
    borderColor: COLORS.line,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 15,
  },
  emptyTitle: {
    color: COLORS.text,
    fontSize: 18,
    fontWeight: "700",
    textAlign: "center",
  },
  emptyText: {
    color: COLORS.muted,
    fontSize: 14,
    lineHeight: 21,
    textAlign: "center",
    marginTop: 8,
    maxWidth: 310,
  },
  emptyAction: {
    marginTop: 22,
    minHeight: 44,
    paddingHorizontal: 15,
    borderRadius: 7,
    backgroundColor: COLORS.amber,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
  },
  emptyActionText: {
    color: COLORS.background,
    fontSize: 14,
    fontWeight: "800",
  },
  pressed: { opacity: 0.72 },
  modalRoot: { flex: 1, justifyContent: "flex-end" },
  modalScrim: {
    position: "absolute",
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    backgroundColor: "rgba(0, 0, 0, 0.68)",
  },
  modalCard: {
    width: "100%",
    maxWidth: 720,
    alignSelf: "center",
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 30,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    borderWidth: 1,
    borderColor: COLORS.line,
    backgroundColor: COLORS.surface,
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginBottom: 22,
  },
  modalEyebrow: {
    color: COLORS.amber,
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.1,
    marginBottom: 5,
  },
  modalTitle: { color: COLORS.text, fontSize: 21, fontWeight: "700" },
  closeButton: {
    width: 42,
    height: 42,
    marginTop: -8,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 21,
    backgroundColor: COLORS.surfaceRaised,
  },
  fieldLabel: {
    color: COLORS.text,
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 8,
  },
  input: {
    minHeight: 50,
    borderRadius: 7,
    borderWidth: 1,
    borderColor: COLORS.line,
    paddingHorizontal: 12,
    color: COLORS.text,
    backgroundColor: "#111821",
    fontSize: 15,
  },
  helperText: {
    marginTop: 8,
    color: COLORS.muted,
    lineHeight: 18,
    fontSize: 12,
  },
  cameraLabel: { marginTop: 20 },
  cameraRow: { flexDirection: "row", gap: 10 },
  cameraChoice: {
    flex: 1,
    minHeight: 54,
    paddingHorizontal: 12,
    borderRadius: 7,
    borderColor: COLORS.line,
    borderWidth: 1,
    backgroundColor: "#111821",
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
  },
  cameraChoiceSelected: {
    borderColor: COLORS.amber,
    backgroundColor: "#2D2A20",
  },
  cameraChoiceIndex: {
    color: COLORS.muted,
    fontSize: 12,
    letterSpacing: 1,
    fontWeight: "800",
  },
  cameraChoiceText: { color: COLORS.text, fontSize: 14, fontWeight: "700" },
  cameraChoiceTextSelected: { color: COLORS.amber },
  primaryAction: {
    minHeight: 50,
    marginTop: 20,
    borderRadius: 8,
    backgroundColor: COLORS.amber,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
  },
  primaryActionText: {
    color: COLORS.background,
    fontSize: 15,
    fontWeight: "800",
  },
  disabled: { opacity: 0.6 },
});
