import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { Linking, Platform, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState } from "react";
import {
  Brand,
  Button,
  C,
  Eyebrow,
  Notice,
  styles,
} from "@/components/duocam/ui";
import { useCameras } from "@/lib/cameras/context";
import { cameraMode } from "@/lib/cameras/model";
export default function Settings() {
  const { cameras } = useCameras();
  const router = useRouter();
  const [error, setError] = useState("");
  async function wifi() {
    try {
      if (Platform.OS === "android")
        await Linking.sendIntent("android.settings.WIFI_SETTINGS");
      else if (Platform.OS === "ios") await Linking.openSettings();
      else
        setError(
          "No celular, abra Ajustes → Wi-Fi e selecione a rede da câmera.",
        );
    } catch {
      setError("Abra manualmente os ajustes Wi-Fi do seu celular.");
    }
  }
  return (
    <SafeAreaView style={styles.page} edges={["top", "left", "right"]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: 20 }]}>
        <Brand small />
        <View style={{ gap: 7 }}>
          <Eyebrow>CONEXÃO SEM CONFUSÃO</Eyebrow>
          <Text style={styles.title}>Ajustes & ajuda</Text>
          <Text style={styles.body}>
            Duas câmeras organizadas. Uma rede ativa por vez.
          </Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.section}>Suas câmeras</Text>
          {cameras.map((camera) => (
            <View key={camera.id} style={{ gap: 8 }}>
              <View
                style={{ flexDirection: "row", alignItems: "center", gap: 10 }}
              >
                <Ionicons name="videocam-outline" size={21} color={C.amber} />
                <View style={{ flex: 1 }}>
                  <Text style={{ color: C.text, fontWeight: "600" }}>
                    0{camera.id} · {camera.name}
                  </Text>
                  <Text style={{ color: C.muted, fontSize: 12, marginTop: 3 }}>
                    {camera.ssid} ·{" "}
                    {cameraMode(camera) === "discovery"
                      ? "Descoberta experimental"
                      : camera.url
                        ? "URL manual salva"
                        : "Sem URL manual"}
                  </Text>
                </View>
              </View>
              <Button
                title="Editar conexão"
                variant="secondary"
                icon="options-outline"
                onPress={() =>
                  router.push({
                    pathname: "/camera/edit",
                    params: { id: camera.id },
                  })
                }
              />
            </View>
          ))}
        </View>
        <View style={styles.card}>
          <Text style={styles.section}>Como conectar</Text>
          {[
            [
              "01",
              "Ligue a câmera",
              "Confirme que o Wi-Fi da V100 está ativo.",
            ],
            [
              "02",
              "Escolha a rede no celular",
              "Conecte à rede da câmera desejada. Se o Android avisar que não há internet, mantenha essa conexão.",
            ],
            [
              "03",
              "Volte e conecte o vídeo",
              "Em Editar conexão, escolha Descobrir V100 e confirme o gateway mostrado como Roteador no Wi-Fi (padrão 192.168.169.1). Salve, volte e toque em Conectar. Cadastros anteriores continuam em URL manual até você escolher o novo modo.",
            ],
            [
              "04",
              "Para trocar de câmera",
              "Pare a visualização, escolha a outra rede no Android e volte ao app. Finalize gravações antes de trocar.",
            ],
          ].map(([num, title, body]) => (
            <View key={num} style={{ flexDirection: "row", gap: 13 }}>
              <Text
                style={{
                  color: C.amber,
                  fontFamily: "monospace",
                  fontSize: 18,
                }}
              >
                {num}
              </Text>
              <View style={{ flex: 1, gap: 4 }}>
                <Text
                  style={{ color: C.text, fontWeight: "600", fontSize: 14 }}
                >
                  {title}
                </Text>
                <Text style={styles.body}>{body}</Text>
              </View>
            </View>
          ))}
          <Button
            title="Abrir ajustes Wi-Fi"
            icon="wifi-outline"
            onPress={wifi}
          />
          {!!error && <Notice>{error}</Notice>}
        </View>
        <Notice>
          Renomear duas redes com o mesmo nome não une as conexões. Para duas
          imagens simultâneas seria necessário outro arranjo de rede compatível.
        </Notice>
        <View style={styles.card}>
          <Text style={styles.section}>O que esta versão faz</Text>
          <Text style={styles.body}>
            Consulta experimental de identificação e endereço de vídeo no
            aparelho, ou URL manual compatível. Transporte RTSP
            Automático/TCP/UDP, áudio, captura e gravação local no player
            nativo, biblioteca e download direto. Nada é enviado para a nuvem. A
            senha Wi-Fi permanece nos ajustes do Android, separada da
            autenticação de vídeo.
          </Text>
          <Text style={styles.body}>
            No cadastro em modo descoberta, Abertura de sessão é opcional e
            começa desativada. Ativada, envia enterrecorder antes do vídeo. Não
            é somente leitura; cancelar não desfaz uma sessão já aceita. Não
            enviamos saída automaticamente.
          </Text>
          <Text style={styles.section}>O que ainda depende da V100</Text>
          <Text style={styles.body}>
            Confirmar que o firmware responde à descoberta e testar o vídeo no
            aparelho. Não reproduzimos login ou sessão proprietária ainda não
            identificados. Consulta concluída não significa imagem: REPRODUZINDO
            exige faixa de vídeo e tempo avançando no player. Controles do
            cartão, resolução, gravação no equipamento e listagem remota exigem
            documentação específica e não estão disponíveis nesta versão.
          </Text>
        </View>
        <Notice>
          A Prévia e o Expo Go não incluem o player RTSP. Gere o APK no painel
          Manus para incluir o patch nativo de TCP; atualizar só o JavaScript
          não basta. A compatibilidade real ainda precisa ser confirmada na
          V100: conexão sem imagem não valida vídeo.
        </Notice>
        <Text style={{ color: C.muted, fontSize: 11, textAlign: "center" }}>
          DUOCAM 1.0 · CÓDIGO ORIGINAL · SEM VÍDEOS SIMULADOS
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}
