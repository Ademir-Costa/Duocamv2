import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Brand,
  Button,
  C,
  Eyebrow,
  IconButton,
  Notice,
  styles,
} from "@/components/duocam/ui";
import { CameraPanel } from "@/components/camera/camera-panel";
import { hasNativePlayer } from "@/components/camera/live-player";
import ConnectedPlayer from "@/components/camera/connected-player";
import type { PlayerHandle } from "@/components/camera/player-types";
import { useCameras } from "@/lib/cameras/context";
import {
  EMPTY_SESSION,
  selectSession,
  updateSession,
  validateConnection,
  type Camera,
  type CameraId,
  type SessionStatus,
} from "@/lib/cameras/model";
import {
  addMedia,
  createCapturePath,
  getRecordingDirectory,
} from "@/lib/media/storage";

type Recording = "idle" | "requested" | "finishing";
export default function CamerasScreen() {
  const router = useRouter();
  const { cameras, selected, setSelected, ready, storageError } = useCameras();
  const [session, setSession] = useState(EMPTY_SESSION);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [muted, setMuted] = useState(true);
  const [expanded, setExpanded] = useState(false);
  const [recording, setRecording] = useState<Recording>("idle");
  const [capturing, setCapturing] = useState(false);
  const [busy, setBusy] = useState(false);
  const player = useRef<PlayerHandle>(null);
  const recordingRef = useRef<Recording>("idle");
  const captureRef = useRef<{ camera: Camera; path: string } | null>(null);
  const recordCamera = useRef<{ camera: Camera; generation: number } | null>(
    null,
  );
  const captureTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const recordTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const leaveAfterRecording = useRef(false);
  const busyRef = useRef(false);
  const sessionRef = useRef(session);
  sessionRef.current = session;
  const activeCamera = cameras.find((c) => c.id === session.cameraId);
  const chosenCamera = cameras.find((c) => c.id === selected)!;
  const canCapture =
    session.status === "playing" &&
    hasNativePlayer() &&
    !capturing &&
    recording !== "finishing";
  function setRecordingState(value: Recording) {
    recordingRef.current = value;
    setRecording(value);
  }
  function locked() {
    if (!ready) {
      setMessage("Aguarde o carregamento das câmeras salvas.");
      return true;
    }
    if (
      busyRef.current ||
      captureRef.current ||
      recordingRef.current !== "idle"
    ) {
      setMessage(
        "Finalize a captura ou gravação local antes de trocar de câmera.",
      );
      return true;
    }
    return false;
  }
  const stopRecording = useCallback(() => {
    if (recordingRef.current !== "requested") return;
    try {
      player.current?.stopRecording();
      recordingRef.current = "finishing";
      setRecording("finishing");
      recordTimer.current = setTimeout(() => {
        recordingRef.current = "idle";
        setRecording("idle");
        recordCamera.current = null;
        setSession((s) => selectSession(s, null));
        setError(
          "Não recebemos confirmação do arquivo de gravação. Nenhum vídeo foi adicionado à biblioteca.",
        );
        if (leaveAfterRecording.current) {
          setSession((s) => selectSession(s, null));
          leaveAfterRecording.current = false;
        }
      }, 15000);
    } catch {
      recordingRef.current = "idle";
      setRecording("idle");
      recordCamera.current = null;
      setSession((s) => selectSession(s, null));
      setError("Não foi possível finalizar a gravação local.");
    }
  }, []);
  useFocusEffect(
    useCallback(
      () => () => {
        if (recordingRef.current !== "idle") {
          leaveAfterRecording.current = true;
          stopRecording();
        } else {
          setSession((s) => selectSession(s, null));
          setExpanded(false);
        }
      },
      [stopRecording],
    ),
  );
  useEffect(
    () => () => {
      if (captureTimer.current) clearTimeout(captureTimer.current);
      if (recordTimer.current) clearTimeout(recordTimer.current);
    },
    [],
  );
  const generation = session.generation;
  const onStatus = useCallback(
    (status: SessionStatus, detail?: string) => {
      if (sessionRef.current.generation !== generation) return;
      if (status === "playing" && sessionRef.current.status !== "playing")
        setError(null);
      setSession((s) => updateSession(s, generation, status));
      if (detail) setError(detail);
    },
    [generation],
  );
  async function onSnapshot(event: {
    success: boolean;
    path?: string;
    error?: string;
  }) {
    const request = captureRef.current;
    if (!request) return;
    captureRef.current = null;
    if (captureTimer.current) clearTimeout(captureTimer.current);
    try {
      if (!event.success)
        throw new Error(event.error || "O player não confirmou a foto.");
      await addMedia({
        cameraId: request.camera.id,
        cameraName: request.camera.name,
        kind: "photo",
        uri: event.path || request.path,
        name: `Foto ${request.camera.name}`,
      });
      setMessage("Foto salva na biblioteca deste dispositivo.");
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Não foi possível salvar a foto.",
      );
    } finally {
      setCapturing(false);
    }
  }
  async function onRecordingCreated(path: string, callbackGeneration: number) {
    const request = recordCamera.current;
    if (
      !request ||
      request.generation !== callbackGeneration ||
      recordingRef.current !== "finishing"
    )
      return;
    const camera = request.camera;
    recordCamera.current = null;
    if (recordTimer.current) clearTimeout(recordTimer.current);
    try {
      if (!path) throw new Error("O player não informou o arquivo de vídeo.");
      await addMedia({
        cameraId: camera.id,
        cameraName: camera.name,
        kind: "video",
        uri: path,
        name: `Vídeo ${camera.name}`,
      });
      setMessage("Vídeo local confirmado e salvo na biblioteca.");
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Não foi possível salvar o vídeo.",
      );
    } finally {
      setRecordingState("idle");
      if (leaveAfterRecording.current) {
        setSession((s) => selectSession(s, null));
        setExpanded(false);
        leaveAfterRecording.current = false;
      }
    }
  }
  function select(id: CameraId) {
    if (locked()) return;
    setSession((s) => selectSession(s, null));
    setSelected(id);
    setError(null);
    setMessage(null);
  }
  function edit(id: CameraId) {
    if (locked()) return;
    setSession((s) => selectSession(s, null));
    router.push({ pathname: "/camera/edit", params: { id } });
  }
  function connect() {
    if (locked()) return;
    const issue = validateConnection(chosenCamera);
    if (issue) {
      setError(issue);
      return;
    }
    setError(null);
    setMessage(null);
    setSession((s) => selectSession(s, chosenCamera.id));
  }
  async function wifi() {
    if (locked()) return;
    setSession((s) => selectSession(s, null));
    setError(null);
    try {
      if (Platform.OS === "android")
        await Linking.sendIntent("android.settings.WIFI_SETTINGS");
      else if (Platform.OS === "ios") await Linking.openSettings();
      else
        setMessage(
          `No celular, abra Ajustes → Wi-Fi e conecte à rede ${chosenCamera.ssid}. Depois volte e toque em Conectar.`,
        );
    } catch {
      setMessage(
        "Abra manualmente os ajustes Wi-Fi do celular e selecione a rede da câmera.",
      );
    }
  }
  function stop() {
    if (locked()) return;
    setSession((s) => selectSession(s, null));
    setError(null);
  }
  function expand(value: boolean) {
    if (locked()) return;
    if (session.cameraId) setSession((s) => selectSession(s, s.cameraId));
    setExpanded(value);
  }
  async function capture() {
    if (!canCapture || !activeCamera || busyRef.current) return;
    setCapturing(true);
    setError(null);
    busyRef.current = true;
    try {
      const path = await createCapturePath("photo");
      captureRef.current = { camera: { ...activeCamera }, path };
      player.current?.snapshot(path);
      captureTimer.current = setTimeout(() => {
        captureRef.current = null;
        setCapturing(false);
        setError(
          "A captura não foi confirmada pelo player. Tente novamente no APK nativo.",
        );
      }, 12000);
    } catch (e) {
      captureRef.current = null;
      setCapturing(false);
      setError(e instanceof Error ? e.message : "Falha na captura.");
    } finally {
      busyRef.current = false;
    }
  }
  async function startRecording() {
    if (
      !activeCamera ||
      session.status !== "playing" ||
      busyRef.current ||
      capturing ||
      recordingRef.current !== "idle"
    )
      return;
    busyRef.current = true;
    setBusy(true);
    setError(null);
    try {
      const directory = await getRecordingDirectory();
      recordCamera.current = {
        camera: { ...activeCamera },
        generation: session.generation,
      };
      player.current?.startRecording(directory);
      setRecordingState("requested");
      setMessage(
        "Gravação local solicitada. O arquivo só será confirmado ao finalizar.",
      );
    } catch (e) {
      recordCamera.current = null;
      setError(
        e instanceof Error
          ? e.message
          : "Não foi possível solicitar a gravação.",
      );
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }
  const video = session.cameraId ? (
    <ConnectedPlayer
      key={session.generation}
      ref={player}
      camera={activeCamera!}
      onDiagnostic={setMessage}
      muted={muted}
      onStatus={onStatus}
      onSnapshot={onSnapshot}
      onRecordingCreated={(path) => onRecordingCreated(path, generation)}
    />
  ) : null;
  const controls = (
    <View style={{ gap: 12 }}>
      <View style={{ flexDirection: "row", gap: 9 }}>
        <Button
          title={capturing ? "Capturando…" : "Foto"}
          icon="camera-outline"
          onPress={capture}
          disabled={!canCapture || busy}
          variant="secondary"
          style={{ flex: 1 }}
        />
        <Button
          title={
            recording === "finishing"
              ? "Finalizando…"
              : recording === "requested"
                ? "Finalizar"
                : "Gravar local"
          }
          icon={
            recording === "requested"
              ? "stop-circle-outline"
              : "radio-button-on-outline"
          }
          onPress={recording === "requested" ? stopRecording : startRecording}
          disabled={
            recording === "finishing" ||
            busy ||
            (recording === "idle" && !canCapture)
          }
          variant="secondary"
          style={{ flex: 1 }}
        />
        <IconButton
          icon={muted ? "volume-mute-outline" : "volume-high-outline"}
          label={muted ? "Ativar áudio" : "Silenciar áudio"}
          onPress={() => setMuted((v) => !v)}
          disabled={!session.cameraId}
        />
      </View>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text
          style={{
            color: recording !== "idle" ? C.amber : C.muted,
            fontSize: 11,
            flex: 1,
          }}
        >
          {recording === "requested"
            ? "Gravação solicitada · confirmação ao finalizar"
            : recording === "finishing"
              ? "Aguardando confirmação do arquivo…"
              : "Captura e gravação no celular, não no cartão SD."}
        </Text>
        <Pressable
          accessibilityRole="button"
          onPress={stop}
          disabled={!session.cameraId}
          style={{ padding: 10 }}
        >
          <Text
            style={{
              color: session.cameraId ? C.red : C.muted,
              fontSize: 12,
              fontWeight: "600",
            }}
          >
            Parar vídeo
          </Text>
        </Pressable>
      </View>
    </View>
  );
  return (
    <SafeAreaView style={styles.page} edges={["top", "left", "right"]}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: 20, gap: 18 }]}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Brand />
          <View
            style={{
              borderWidth: 1,
              borderColor: C.line,
              borderRadius: 20,
              paddingVertical: 7,
              paddingHorizontal: 11,
              flexDirection: "row",
              gap: 5,
              alignItems: "center",
            }}
          >
            <Ionicons
              name="shield-checkmark-outline"
              size={12}
              color={C.muted}
            />
            <Text style={{ fontSize: 9, color: C.muted, letterSpacing: 1 }}>
              LOCAL & PRIVADO
            </Text>
          </View>
        </View>
        <View style={{ gap: 6, marginTop: 6 }}>
          <Eyebrow>VISUALIZAÇÃO WI-FI</Eyebrow>
          <Text style={styles.title}>{"Seu caminho,\npor outro ângulo."}</Text>
          <Text style={styles.body}>
            Duas câmeras. Uma conexão ativa por vez.
          </Text>
        </View>
        <View
          style={{
            flexDirection: "row",
            padding: 5,
            backgroundColor: C.surface,
            borderRadius: 12,
            gap: 6,
          }}
        >
          {cameras.map((camera) => (
            <Pressable
              key={camera.id}
              accessibilityRole="button"
              accessibilityLabel={`Selecionar câmera ${camera.id}`}
              onPress={() => select(camera.id)}
              style={{
                flex: 1,
                minHeight: 43,
                backgroundColor:
                  selected === camera.id ? C.amber : "transparent",
                borderRadius: 9,
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "row",
                gap: 7,
              }}
            >
              <Ionicons
                name="videocam-outline"
                color={selected === camera.id ? C.bg : C.muted}
                size={17}
              />
              <Text
                style={{
                  color: selected === camera.id ? C.bg : C.muted,
                  fontWeight: "600",
                  fontSize: 13,
                }}
              >
                Câmera 0{camera.id}
              </Text>
            </Pressable>
          ))}
        </View>
        {storageError && <Notice danger>{storageError}</Notice>}
        {cameras.map((camera) => (
          <CameraPanel
            key={camera.id}
            camera={camera}
            selected={selected === camera.id}
            status={session.cameraId === camera.id ? session.status : "idle"}
            onSelect={() => select(camera.id)}
            onEdit={() => edit(camera.id)}
            onConnect={connect}
            onExpand={() => expand(true)}
            error={session.cameraId === camera.id ? error : null}
          >
            {session.cameraId === camera.id && !expanded ? video : null}
          </CameraPanel>
        ))}
        {controls}
        {!!error && !session.cameraId && <Notice danger>{error}</Notice>}
        {!!message && <Notice>{message}</Notice>}
        <View style={{ height: 1, backgroundColor: C.line }} />
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 12,
          }}
        >
          <View style={{ flex: 1, gap: 4 }}>
            <Text style={{ color: C.text, fontSize: 14, fontWeight: "600" }}>
              Rede da câmera selecionada
            </Text>
            <Text
              style={{ color: C.amber, fontSize: 12, fontFamily: "monospace" }}
            >
              {chosenCamera.ssid}
            </Text>
          </View>
          <Button
            title="Abrir Wi-Fi"
            icon="wifi-outline"
            variant="secondary"
            onPress={wifi}
            disabled={!ready}
          />
        </View>
        <Notice>
          Antes de conectar, escolha o Wi-Fi da câmera no Android. O nome acima
          é o cadastro, não uma confirmação da rede atual.
        </Notice>
        {!hasNativePlayer() && (
          <Text style={{ color: C.muted, fontSize: 11, lineHeight: 18 }}>
            Prévia de interface: vídeo RTSP, foto e gravação requerem o APK
            Android com player nativo. Nenhuma imagem aqui é simulada.
          </Text>
        )}
      </ScrollView>
      <Modal
        visible={expanded}
        animationType="fade"
        onRequestClose={() => expand(false)}
      >
        <SafeAreaView
          style={styles.page}
          edges={["top", "left", "right", "bottom"]}
        >
          <View
            style={{
              padding: 20,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <View>
              <Eyebrow>VISUALIZAÇÃO AMPLIADA</Eyebrow>
              <Text
                style={{
                  color: C.text,
                  fontSize: 20,
                  fontWeight: "600",
                  marginTop: 8,
                }}
              >
                {chosenCamera.name}
              </Text>
            </View>
            <IconButton
              icon="contract-outline"
              label="Fechar visualização ampliada"
              onPress={() => expand(false)}
            />
          </View>
          <View style={{ flex: 1, backgroundColor: "#080B10" }}>
            {expanded
              ? video || (
                  <View
                    style={{
                      flex: 1,
                      justifyContent: "center",
                      alignItems: "center",
                      gap: 16,
                    }}
                  >
                    <Ionicons
                      name="videocam-outline"
                      size={48}
                      color={C.amber}
                    />
                    <Text style={styles.body}>
                      Selecione o Wi-Fi e conecte a câmera.
                    </Text>
                    <Button title="Conectar vídeo" onPress={connect} />
                  </View>
                )
              : null}
          </View>
          <View style={{ padding: 20, gap: 12 }}>
            {controls}
            {!!error && <Notice danger>{error}</Notice>}
            {!!message && <Notice>{message}</Notice>}
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}
