import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Sharing from "expo-sharing";
import { VideoView, useVideoPlayer } from "expo-video";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { deleteMedia, getMedia, type MediaItem } from "@/lib/media/storage";

const COLORS = {
  background: "#10141B",
  surface: "#1B222D",
  surfaceRaised: "#232C38",
  amber: "#F4B545",
  text: "#F2F4F7",
  muted: "#8D99AB",
  line: "#324051",
  danger: "#E77272",
};

function formatDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Data indisponível";
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "long",
    timeStyle: "short",
  }).format(date);
}

function LocalVideo({ uri }: { uri: string }) {
  const player = useVideoPlayer(uri, (videoPlayer) => {
    videoPlayer.loop = false;
  });

  useEffect(() => {
    return () => {
      player.pause();
    };
  }, [player]);

  return (
    <VideoView
      nativeControls
      player={player}
      style={styles.video}
      contentFit="contain"
    />
  );
}

export default function MediaScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string | string[] }>();
  const id = Array.isArray(params.id) ? params.id[0] : params.id;
  const [item, setItem] = useState<MediaItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [webDeleteVisible, setWebDeleteVisible] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const media = await getMedia();
      setItem(media.find((entry) => entry.id === id) ?? null);
    } catch (cause) {
      setMessage(
        cause instanceof Error
          ? cause.message
          : "Não foi possível abrir esse arquivo.",
      );
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void load();
  }, [load]);

  const share = async () => {
    if (!item) return;
    setBusy(true);
    setMessage(null);
    try {
      if (!(await Sharing.isAvailableAsync())) {
        throw new Error(
          "O compartilhamento não está disponível neste dispositivo.",
        );
      }
      await Sharing.shareAsync(item.uri, {
        dialogTitle: `Compartilhar ${item.name}`,
        mimeType: item.kind === "photo" ? "image/*" : "video/*",
      });
    } catch (cause) {
      setMessage(
        cause instanceof Error
          ? cause.message
          : "Não foi possível compartilhar o arquivo.",
      );
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!item) return;
    setBusy(true);
    setMessage(null);
    try {
      await deleteMedia(item.id);
      setWebDeleteVisible(false);
      router.back();
    } catch (cause) {
      setMessage(
        cause instanceof Error
          ? cause.message
          : "Não foi possível excluir o arquivo.",
      );
    } finally {
      setBusy(false);
    }
  };

  const confirmDelete = () => {
    if (!item || busy) return;
    if (Platform.OS === "web") {
      setWebDeleteVisible(true);
      return;
    }
    Alert.alert(
      "Excluir arquivo?",
      `“${item.name}” será apagado deste aparelho e não poderá ser recuperado.`,
      [
        { text: "Cancelar", style: "cancel" },
        { text: "Excluir", style: "destructive", onPress: () => void remove() },
      ],
    );
  };

  if (loading) {
    return (
      <SafeAreaView edges={["top", "left", "right"]} style={styles.safeArea}>
        <View style={styles.centered}>
          <ActivityIndicator color={COLORS.amber} size="large" />
          <Text style={styles.loadingText}>Abrindo arquivo local…</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!item) {
    return (
      <SafeAreaView edges={["top", "left", "right"]} style={styles.safeArea}>
        <View style={styles.notFound}>
          <View style={styles.notFoundIcon}>
            <Ionicons color={COLORS.amber} name="file-tray-outline" size={35} />
          </View>
          <Text style={styles.notFoundTitle}>Arquivo indisponível</Text>
          <Text style={styles.notFoundText}>
            {message ??
              "Ele pode ter sido excluído do aparelho ou não existe mais na biblioteca."}
          </Text>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [
              styles.backAction,
              pressed && styles.pressed,
            ]}
          >
            <Ionicons color={COLORS.background} name="arrow-back" size={19} />
            <Text style={styles.backActionText}>Voltar à biblioteca</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView edges={["top", "left", "right"]} style={styles.safeArea}>
      <View style={styles.screen}>
        <View style={styles.topBar}>
          <Pressable
            accessibilityLabel="Voltar"
            onPress={() => router.back()}
            style={({ pressed }) => [
              styles.iconButton,
              pressed && styles.pressed,
            ]}
          >
            <Ionicons color={COLORS.text} name="arrow-back" size={23} />
          </Pressable>
          <Text numberOfLines={1} style={styles.topTitle}>
            Visualizar mídia
          </Text>
          <View style={styles.topSpacer} />
        </View>

        <View style={styles.viewer}>
          {item.kind === "photo" ? (
            <Image
              accessibilityLabel={item.name}
              resizeMode="contain"
              source={{ uri: item.uri }}
              style={styles.image}
            />
          ) : (
            <LocalVideo uri={item.uri} />
          )}
        </View>

        <View style={styles.details}>
          <View style={styles.typeRow}>
            <Ionicons
              color={COLORS.amber}
              name={
                item.kind === "photo" ? "image-outline" : "videocam-outline"
              }
              size={16}
            />
            <Text style={styles.typeText}>
              {item.kind === "photo" ? "FOTO LOCAL" : "VÍDEO LOCAL"}
            </Text>
          </View>
          <Text numberOfLines={2} style={styles.fileName}>
            {item.name}
          </Text>
          <Text style={styles.meta}>
            {item.cameraName} · {formatDate(item.createdAt)}
          </Text>
          <Text style={styles.detailNote}>
            Salvo somente neste aparelho. Compartilhar não envia o arquivo ao
            DuoCam.
          </Text>

          {message ? (
            <View style={styles.messageBox}>
              <Ionicons
                color={COLORS.danger}
                name="alert-circle-outline"
                size={19}
              />
              <Text style={styles.messageText}>{message}</Text>
            </View>
          ) : null}

          <View style={styles.actionRow}>
            <Pressable
              accessibilityRole="button"
              disabled={busy}
              onPress={() => void share()}
              style={({ pressed }) => [
                styles.shareAction,
                (pressed || busy) && styles.pressed,
                busy && styles.disabled,
              ]}
            >
              {busy ? (
                <ActivityIndicator color={COLORS.background} />
              ) : (
                <Ionicons
                  color={COLORS.background}
                  name="share-outline"
                  size={20}
                />
              )}
              <Text style={styles.shareActionText}>Compartilhar</Text>
            </Pressable>
            <Pressable
              accessibilityLabel="Excluir arquivo"
              accessibilityRole="button"
              disabled={busy}
              onPress={confirmDelete}
              style={({ pressed }) => [
                styles.deleteAction,
                (pressed || busy) && styles.pressed,
                busy && styles.disabled,
              ]}
            >
              <Ionicons color={COLORS.danger} name="trash-outline" size={21} />
            </Pressable>
          </View>
        </View>
      </View>

      <Modal
        animationType="fade"
        transparent
        visible={webDeleteVisible}
        onRequestClose={() => setWebDeleteVisible(false)}
      >
        <View style={styles.modalRoot}>
          <Pressable
            onPress={() => !busy && setWebDeleteVisible(false)}
            style={styles.modalScrim}
          />
          <View accessibilityViewIsModal style={styles.confirmCard}>
            <Ionicons color={COLORS.danger} name="trash-outline" size={28} />
            <Text style={styles.confirmTitle}>Excluir arquivo?</Text>
            <Text style={styles.confirmText}>
              “{item.name}” será removido da biblioteca local e não poderá ser
              recuperado.
            </Text>
            <View style={styles.confirmActions}>
              <Pressable
                disabled={busy}
                onPress={() => setWebDeleteVisible(false)}
                style={styles.cancelAction}
              >
                <Text style={styles.cancelActionText}>Cancelar</Text>
              </Pressable>
              <Pressable
                disabled={busy}
                onPress={() => void remove()}
                style={({ pressed }) => [
                  styles.confirmDeleteAction,
                  (pressed || busy) && styles.pressed,
                ]}
              >
                {busy ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.confirmDeleteText}>Excluir</Text>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  screen: { flex: 1, width: "100%", maxWidth: 720, alignSelf: "center" },
  centered: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 13,
    padding: 28,
  },
  loadingText: { color: COLORS.muted, fontSize: 14 },
  topBar: {
    paddingHorizontal: 20,
    minHeight: 62,
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: COLORS.line,
  },
  iconButton: {
    height: 44,
    width: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: COLORS.surface,
  },
  topTitle: {
    flex: 1,
    color: COLORS.text,
    fontSize: 16,
    fontWeight: "700",
    textAlign: "center",
  },
  topSpacer: { width: 44 },
  viewer: {
    flex: 1,
    minHeight: 250,
    margin: 20,
    marginBottom: 0,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.line,
    backgroundColor: "#090D12",
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
  },
  image: { height: "100%", width: "100%" },
  video: { height: "100%", width: "100%" },
  details: { padding: 20, paddingBottom: 28 },
  typeRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  typeText: {
    color: COLORS.amber,
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1,
  },
  fileName: {
    color: COLORS.text,
    fontSize: 21,
    fontWeight: "700",
    marginTop: 8,
    lineHeight: 27,
  },
  meta: { color: COLORS.muted, fontSize: 13, lineHeight: 19, marginTop: 6 },
  detailNote: {
    color: COLORS.muted,
    fontSize: 12,
    lineHeight: 18,
    marginTop: 10,
  },
  messageBox: {
    marginTop: 16,
    padding: 11,
    gap: 8,
    flexDirection: "row",
    borderWidth: 1,
    borderColor: "#6D373A",
    borderRadius: 8,
    backgroundColor: "#2B1F24",
  },
  messageText: { color: "#FFD8D8", flex: 1, fontSize: 13, lineHeight: 18 },
  actionRow: { flexDirection: "row", gap: 10, marginTop: 20 },
  shareAction: {
    flex: 1,
    minHeight: 50,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    flexDirection: "row",
    backgroundColor: COLORS.amber,
    borderRadius: 8,
  },
  shareActionText: {
    color: COLORS.background,
    fontSize: 15,
    fontWeight: "800",
  },
  deleteAction: {
    minHeight: 50,
    width: 54,
    alignItems: "center",
    justifyContent: "center",
    borderColor: "#744044",
    borderWidth: 1,
    borderRadius: 8,
    backgroundColor: "#291C22",
  },
  notFound: {
    flex: 1,
    maxWidth: 720,
    alignSelf: "center",
    width: "100%",
    justifyContent: "center",
    alignItems: "center",
    padding: 30,
  },
  notFoundIcon: {
    height: 70,
    width: 70,
    borderRadius: 35,
    borderWidth: 1,
    borderColor: COLORS.line,
    backgroundColor: COLORS.surface,
    alignItems: "center",
    justifyContent: "center",
  },
  notFoundTitle: {
    color: COLORS.text,
    fontSize: 20,
    fontWeight: "700",
    marginTop: 16,
  },
  notFoundText: {
    color: COLORS.muted,
    textAlign: "center",
    lineHeight: 21,
    fontSize: 14,
    marginTop: 8,
    maxWidth: 320,
  },
  backAction: {
    minHeight: 46,
    paddingHorizontal: 15,
    marginTop: 22,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    flexDirection: "row",
    borderRadius: 8,
    backgroundColor: COLORS.amber,
  },
  backActionText: { color: COLORS.background, fontWeight: "800", fontSize: 14 },
  pressed: { opacity: 0.72 },
  disabled: { opacity: 0.58 },
  modalRoot: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  modalScrim: {
    position: "absolute",
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
  },
  confirmCard: {
    width: "100%",
    maxWidth: 390,
    padding: 22,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.line,
    backgroundColor: COLORS.surface,
  },
  confirmTitle: {
    color: COLORS.text,
    fontSize: 19,
    fontWeight: "700",
    marginTop: 13,
  },
  confirmText: {
    color: COLORS.muted,
    fontSize: 14,
    lineHeight: 20,
    marginTop: 7,
  },
  confirmActions: {
    marginTop: 22,
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 10,
  },
  cancelAction: {
    minHeight: 42,
    paddingHorizontal: 14,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 1,
    borderColor: COLORS.line,
    borderRadius: 7,
  },
  cancelActionText: { color: COLORS.text, fontSize: 14, fontWeight: "700" },
  confirmDeleteAction: {
    minHeight: 42,
    minWidth: 88,
    paddingHorizontal: 14,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 7,
    backgroundColor: "#B8494D",
  },
  confirmDeleteText: { color: "#FFFFFF", fontSize: 14, fontWeight: "800" },
});
